/*
# Security fixes: function search_path, RLS policy, storage listing

1. Function Search Path Mutable
   - Recreate public.set_updated_at() with an explicit `SET search_path = public, pg_temp`
   - so it is not vulnerable to search_path hijacking.
   - Triggers on profiles and listings depend on it, so drop those triggers,
     recreate the function, then recreate the triggers.

2. RLS Policy Always True
   - Drop the `feedback_insert_any` policy whose WITH CHECK is `true`.
   - Replace with `feedback_insert_own` requiring `auth.uid() = user_id`
     scoped to `authenticated` only.

3. Public Bucket Allows Listing (avatars)
   - Drop the broad `avatars_public_read` SELECT policy.
   - Replace with a policy scoped to the object owner only.

4. Public Bucket Allows Listing (listings-images)
   - Drop the broad `listings_images_public_read` SELECT policy.
   - Replace with a policy scoped to the object owner only.
*/

-- 1. Fix mutable search_path on set_updated_at()
-- Drop dependent triggers first
DROP TRIGGER IF EXISTS profiles_set_updated_at ON public.profiles;
DROP TRIGGER IF EXISTS listings_set_updated_at ON public.listings;

-- Recreate function with fixed search_path
DROP FUNCTION IF EXISTS public.set_updated_at();
CREATE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public, pg_temp
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Recreate triggers
CREATE TRIGGER profiles_set_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

CREATE TRIGGER listings_set_updated_at
  BEFORE UPDATE ON public.listings
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- 2. Fix feedback INSERT policy
DROP POLICY IF EXISTS "feedback_insert_any" ON public.feedback;
CREATE POLICY "feedback_insert_own" ON public.feedback
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- 3. Fix avatars bucket listing policy
DROP POLICY IF EXISTS "avatars_public_read" ON storage.objects;
CREATE POLICY "avatars_owner_read" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'avatars' AND owner = auth.uid());

-- 4. Fix listings-images bucket listing policy
DROP POLICY IF EXISTS "listings_images_public_read" ON storage.objects;
CREATE POLICY "listings_images_owner_read" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'listings-images' AND owner = auth.uid());

/*
# Add direct FKs from offers/comments to profiles

1. Changes
   - Add FK from offers.bidder_id to profiles.id so PostgREST can resolve
     the offers → profiles join unambiguously.
   - Add FK from comments.user_id to profiles.id for the same reason.
   - Existing FKs to auth.users remain for cascade-on-delete.
2. Security
   - No RLS changes.
*/

ALTER TABLE public.offers
  ADD CONSTRAINT offers_profiles_id_fkey
  FOREIGN KEY (bidder_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

ALTER TABLE public.comments
  ADD CONSTRAINT comments_profiles_id_fkey
  FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

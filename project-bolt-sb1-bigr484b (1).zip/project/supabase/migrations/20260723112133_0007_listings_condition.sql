/*
# Add condition column to listings

1. Changes
   - Add `condition` text column to `listings` to store box/item condition.
   - Values: 'Sıfır / Sorunsuz', 'Koruma Kılıflı / Kablı',
     'Blisteri Hasarlı / Yırtık', 'Kutusu Açık'.
   - Nullable initially (existing rows have no condition); new inserts
     will require a value from the app form.
2. Security
   - No RLS changes needed; existing listing policies cover all columns.
*/

ALTER TABLE public.listings
  ADD COLUMN IF NOT EXISTS condition text;

CREATE INDEX IF NOT EXISTS listings_condition_idx ON public.listings (condition);

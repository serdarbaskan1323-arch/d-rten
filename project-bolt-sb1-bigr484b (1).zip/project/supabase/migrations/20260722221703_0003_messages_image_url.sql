/*
# Add image_url column to messages table

1. Changes
   - Add nullable `image_url` text column to `messages` so users can send
     images in the in-app chat. Text body becomes optional when an image
     is attached.
   - Add a check constraint: at least one of (body, image_url) must be non-null.
2. Security
   - No RLS changes needed; existing message policies already cover INSERT
     with `WITH CHECK (auth.uid() = sender_id)`.
*/

ALTER TABLE public.messages
  ADD COLUMN IF NOT EXISTS image_url text;

ALTER TABLE public.messages DROP CONSTRAINT IF EXISTS messages_content_check;
ALTER TABLE public.messages
  ADD CONSTRAINT messages_content_check
  CHECK (body IS NOT NULL OR image_url IS NOT NULL);

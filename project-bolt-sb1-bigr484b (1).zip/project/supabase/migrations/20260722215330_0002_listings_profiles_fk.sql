/*
# Add direct FK from listings to profiles

1. Changes
   - Add a foreign key constraint from `listings.user_id` to `profiles.id`
     so PostgREST can unambiguously resolve the `listings → profiles` join
     for Supabase JS client queries using `select('*, profiles(*)')`.
   - The existing FK to `auth.users(id)` remains for cascade-on-delete.
2. Security
   - No RLS changes.
*/

ALTER TABLE public.listings
  ADD CONSTRAINT listings_profiles_id_fkey
  FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

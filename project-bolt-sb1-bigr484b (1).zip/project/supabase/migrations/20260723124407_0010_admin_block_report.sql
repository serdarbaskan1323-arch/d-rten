/*
# Admin roles, user blocking, and reporting system

1. profiles table
   - Add `role` column (text, default 'user') to profiles.
   - Set role = 'admin' for the account with email 'cinartr09@gmail.com'.

2. New table: blocked_users
   - Stores block relationships: blocker_id, blocked_id, created_at.
   - PK on (blocker_id, blocked_id) prevents duplicate blocks.
   - FK to auth.users on both columns with CASCADE on user deletion.

3. New table: reports
   - Stores user/listing reports: reporter_id, reported_user_id,
     listing_id (nullable), reason, description, status, created_at.
   - FK to auth.users for reporter and reported user.
   - FK to listings for the reported listing (nullable, CASCADE on delete).

4. Security (RLS)
   - blocked_users: owner-scoped CRUD (blocker can insert/delete their own blocks,
     anyone authenticated can read their own blocked rows).
   - reports: authenticated users can INSERT reports; users can SELECT their own
     reports; admin users can SELECT/UPDATE all reports.
   - Admin role check uses a SECURITY DEFINER function is_admin() that checks
     profiles.role = 'admin' for the current user.

5. Notes
   - No existing data is dropped or altered.
   - The is_admin() function is reusable for any admin-only RLS policy.
*/

-- 1. Add role column to profiles ------------------------------------------------
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'user';

-- Set admin for the specified email
UPDATE public.profiles
SET role = 'admin'
WHERE id = (
  SELECT id FROM auth.users WHERE email = 'cinartr09@gmail.com'
);

-- 2. is_admin() helper function -------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$;

-- 3. blocked_users table --------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.blocked_users (
  blocker_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (blocker_id, blocked_id)
);

ALTER TABLE public.blocked_users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_blocks" ON public.blocked_users;
CREATE POLICY "select_own_blocks" ON public.blocked_users
  FOR SELECT TO authenticated
  USING (auth.uid() = blocker_id);

DROP POLICY IF EXISTS "insert_own_blocks" ON public.blocked_users;
CREATE POLICY "insert_own_blocks" ON public.blocked_users
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = blocker_id);

DROP POLICY IF EXISTS "delete_own_blocks" ON public.blocked_users;
CREATE POLICY "delete_own_blocks" ON public.blocked_users
  FOR DELETE TO authenticated
  USING (auth.uid() = blocker_id);

-- 4. reports table --------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reported_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  listing_id uuid REFERENCES public.listings(id) ON DELETE CASCADE,
  reason text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

-- Any authenticated user can file a report (INSERT)
DROP POLICY IF EXISTS "insert_reports" ON public.reports;
CREATE POLICY "insert_reports" ON public.reports
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = reporter_id);

-- Users can see their own reports; admins can see all
DROP POLICY IF EXISTS "select_reports" ON public.reports;
CREATE POLICY "select_reports" ON public.reports
  FOR SELECT TO authenticated
  USING (auth.uid() = reporter_id OR public.is_admin());

-- Only admins can update report status
DROP POLICY IF EXISTS "update_reports_admin" ON public.reports;
CREATE POLICY "update_reports_admin" ON public.reports
  FOR UPDATE TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- Only admins can delete reports
DROP POLICY IF EXISTS "delete_reports_admin" ON public.reports;
CREATE POLICY "delete_reports_admin" ON public.reports
  FOR DELETE TO authenticated
  USING (public.is_admin());

-- 5. Index for admin queries
CREATE INDEX IF NOT EXISTS idx_reports_status ON public.reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_created_at ON public.reports(created_at DESC);

/*
# Storage & RLS Hardening

1. Storage Policies — listings-images & avatars buckets
   - INSERT: restrict to authenticated users, owner-scoped (owner_id = auth.uid()),
     and only image file extensions (jpg, jpeg, png, webp, gif).
   - DELETE: owner-only (restated for clarity).

2. RLS verification
   - Re-assert ENABLE ROW LEVEL SECURITY on all tables: profiles, listings,
     messages, feedback, offers, comments.

3. Notes
   - No data is dropped or altered.
   - MIME type enforcement happens via file extension check on the name column,
     plus frontend content-type validation before upload.
*/

-- Re-assert RLS on every table -------------------------------------------------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

-- listings-images: tighten INSERT to owner-scoped + image-only -----------------
DROP POLICY IF EXISTS "listings_images_auth_insert" ON storage.objects;
CREATE POLICY "listings_images_auth_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'listings-images'
    AND owner_id = auth.uid()::text
    AND lower(name) ~ '\.(jpg|jpeg|png|webp|gif)$'
  );

-- listings-images: DELETE owner-scoped
DROP POLICY IF EXISTS "listings_images_auth_delete" ON storage.objects;
CREATE POLICY "listings_images_auth_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'listings-images' AND owner_id = auth.uid()::text);

-- avatars: tighten INSERT to owner-scoped + image-only -------------------------
DROP POLICY IF EXISTS "avatars_auth_insert" ON storage.objects;
CREATE POLICY "avatars_auth_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'avatars'
    AND owner_id = auth.uid()::text
    AND lower(name) ~ '\.(jpg|jpeg|png|webp|gif)$'
  );

-- avatars: DELETE owner-scoped
DROP POLICY IF EXISTS "avatars_auth_delete" ON storage.objects;
CREATE POLICY "avatars_auth_delete" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'avatars' AND owner_id = auth.uid()::text);

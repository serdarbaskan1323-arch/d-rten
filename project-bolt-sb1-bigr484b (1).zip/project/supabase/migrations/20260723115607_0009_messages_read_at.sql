/*
# Add read_at column to messages + UPDATE policy

1. Changes to messages table
   - Add `read_at` timestamptz column (nullable). When NULL the message is unread.
   - This enables unread badge counters and read receipts in the chat UI.

2. Security
   - Add an UPDATE policy so the recipient of a message can mark it as read
     (auth.uid() = recipient_id). The sender cannot modify the message.
   - No existing policies are dropped or changed.

3. Notes
   - No data is dropped or altered. The new column is nullable with no default,
     so existing rows simply have NULL (unread = false for old messages is
     acceptable; the UI treats NULL as "unread").
*/

ALTER TABLE public.messages
  ADD COLUMN IF NOT EXISTS read_at timestamptz;

DROP POLICY IF EXISTS "messages_update_recipient" ON public.messages;
CREATE POLICY "messages_update_recipient" ON public.messages
  FOR UPDATE TO authenticated
  USING (auth.uid() = recipient_id)
  WITH CHECK (auth.uid() = recipient_id);

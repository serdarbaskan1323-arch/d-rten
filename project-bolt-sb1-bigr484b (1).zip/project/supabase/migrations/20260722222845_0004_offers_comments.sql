/*
# Add offers and comments tables for bidding & public Q&A

1. New Tables
   - `offers`: price bids placed by users on a listing. Seller can accept/reject.
     Columns: id, listing_id, bidder_id, amount, status (pending/accepted/rejected),
     created_at.
   - `comments`: public Q&A thread on a listing.
     Columns: id, listing_id, user_id, body, created_at.

2. Security
   - RLS enabled on both tables.
   - offers: SELECT visible to authenticated (public bidding); INSERT by bidder;
     UPDATE/DELETE by listing owner (seller manages offers).
   - comments: SELECT public to authenticated; INSERT by authenticated;
     UPDATE/DELETE by comment author only.

3. Indexes on listing_id for both tables.
*/

CREATE TABLE IF NOT EXISTS public.offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  bidder_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  amount numeric(12,2) NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "offers_select_public" ON public.offers;
CREATE POLICY "offers_select_public" ON public.offers
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "offers_insert_bidder" ON public.offers;
CREATE POLICY "offers_insert_bidder" ON public.offers
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = bidder_id);

DROP POLICY IF EXISTS "offers_update_owner" ON public.offers;
CREATE POLICY "offers_update_owner" ON public.offers
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.listings WHERE listings.id = offers.listing_id AND listings.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.listings WHERE listings.id = offers.listing_id AND listings.user_id = auth.uid()));

DROP POLICY IF EXISTS "offers_delete_owner" ON public.offers;
CREATE POLICY "offers_delete_owner" ON public.offers
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.listings WHERE listings.id = offers.listing_id AND listings.user_id = auth.uid()));

CREATE INDEX IF NOT EXISTS offers_listing_idx ON public.offers (listing_id);
CREATE INDEX IF NOT EXISTS offers_bidder_idx ON public.offers (bidder_id);

CREATE TABLE IF NOT EXISTS public.comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "comments_select_public" ON public.comments;
CREATE POLICY "comments_select_public" ON public.comments
  FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "comments_insert_auth" ON public.comments;
CREATE POLICY "comments_insert_auth" ON public.comments
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "comments_update_own" ON public.comments;
CREATE POLICY "comments_update_own" ON public.comments
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "comments_delete_own" ON public.comments;
CREATE POLICY "comments_delete_own" ON public.comments
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS comments_listing_idx ON public.comments (listing_id);
CREATE INDEX IF NOT EXISTS comments_user_idx ON public.comments (user_id);

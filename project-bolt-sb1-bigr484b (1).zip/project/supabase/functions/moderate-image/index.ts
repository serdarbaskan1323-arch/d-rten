import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ModerationResult {
  valid: boolean;
  reason?: string;
  is_nsfw?: boolean;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const fileName: string = (body.file_name || body.filename || "").toLowerCase();
    const imageUrl: string = body.image_url || "";
    const width: number = body.width || 0;
    const height: number = body.height || 0;
    const fileSize: number = body.file_size || 0;
    const mimeType: string = (body.mime_type || "").toLowerCase();

    // --- Strict file format validation ---
    const allowedExtensions = [".jpg", ".jpeg", ".png", ".webp"];
    const allowedMimes = ["image/jpeg", "image/png", "image/webp"];

    const hasValidExt = allowedExtensions.some((ext) => fileName.endsWith(ext));
    const hasValidMime = !mimeType || allowedMimes.includes(mimeType);

    if (!hasValidExt || !hasValidMime) {
      const result: ModerationResult = {
        valid: false,
        reason: "Sadece JPEG, PNG ve WEBP formatları kabul edilir.",
      };
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // --- Reject obviously non-image file names ---
    const badExtensions = [".pdf", ".doc", ".docx", ".txt", ".mp4", ".mov", ".zip", ".rar", ".exe", ".gif", ".bmp", ".tiff", ".svg"];
    if (badExtensions.some((ext) => fileName.endsWith(ext))) {
      const result: ModerationResult = {
        valid: false,
        reason: "Sadece JPEG, PNG ve WEBP formatları kabul edilir.",
      };
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // --- NSFW keyword check in filename ---
    const nsfwKeywords = [
      "nsfw", "porn", "porno", "xxx", "nude", "nudes", "sex", "sexy",
      "cevşet", "cevset", "cavşet", "cavset",
      "violence", "gore", "weapon", "gun", "bomb", "terror",
      "silah", "bomba", "terör", "müstehcen", "uygunsuz",
      "escort", "bikini", "mayo", "iç çamaşır", "ic camaşir",
      "naked", "topless", "lingerie",
    ];
    if (nsfwKeywords.some((kw) => fileName.includes(kw))) {
      const result: ModerationResult = {
        valid: false,
        is_nsfw: true,
        reason: "Yüklediğiniz görsel uygunsuz içerik tespit edildiği için reddedildi.",
      };
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // --- Reject tiny/placeholder dimensions ---
    if ((width > 0 && width < 50) || (height > 0 && height < 50)) {
      const result: ModerationResult = {
        valid: false,
        reason: "Görsel çok küçük. Lütfen daha net bir görsel yükleyin.",
      };
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // --- Reject files larger than 10MB ---
    if (fileSize > 10 * 1024 * 1024) {
      const result: ModerationResult = {
        valid: false,
        reason: "Görsel boyutu 10MB sınırını aşıyor.",
      };
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // --- Approve valid images ---
    if (imageUrl || fileName) {
      const result: ModerationResult = { valid: true };
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const result: ModerationResult = {
      valid: false,
      reason: "Görsel verisi alınamadı.",
    };
    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("moderate-image error", err);
    return new Response(
      JSON.stringify({ error: "Sunucu hatası, lütfen tekrar deneyin." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

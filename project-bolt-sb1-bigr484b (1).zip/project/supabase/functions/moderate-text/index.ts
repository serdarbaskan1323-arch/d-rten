import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const PROFANITY_TR = [
  "amk", "aq", "a.q", "a.q.", "aq.", "amına", "amina", "amcık", "amcik",
  "sik", "s1k", "siq", "sikim", "siker", "sikti", "siktir", "sikdir",
  "piç", "pic", "p1ç", "orospu", "orospu çocuğu", "oc",
  "pezevenk", "pezo", "yarrak", "yarram", "yarrağım", "yarrağ",
  "göt", "got", "götün", "götveren", "gotveren",
  "salak", "aptal", "gerizekalı", "geri zekalı", "mal", "manyak",
  "kahpe", "kahpe çocuğu", "kahpecocuğu",
  "lan", "lanet", "aqmk", "sg", "siktirgit", "siktir lan",
  "salako", "gerilim", "ibne", "ibne çocuğu", "ibnecik",
  "gavat", "gavatlık", "puşt", "pusht",
  "oç", "o.c", "o.c.", "oc",
  "bok", "boktan", "bok gibi", "boklugari",
  "çüş", "cüs",
  "sürtük", "surtuk",
  "şerefsiz", "serefsiz", "şerefsiz çocuğu",
  "dalyarak", "dalyarrak",
  "yavşak", "yavsak",
  "titiz",
  "kıç", "kic",
  "amq", "amk.",
  "evladı", "evlatsız",
  "godoş", "godos",
  "sürtük",
  "pust",
];

const NSFW_KEYWORDS = [
  "porn", "porno", "nsfw", "xxx", "nude", "nudes", "sex", "sexy",
  "cevşet", "cevset", "cavşet", "cavset",
  "weapon", "gun", "bomb", "terror", "terör",
  "uygunsuz", "müstehcen",
  "escourt", "escort", "escrt",
  "bikini", "mayo", "iç çamaşırı", "ic camasiri",
  "silah", "bomba", "terör",
];

const HATE_KEYWORDS = [
  "kürt düşmanı", "rum düşmanı", "ermeni düşmanı",
  "ırkçı", "irkci", "faşist", "fasist",
  "ne mutlu türküm diyene",
  "nazi", "hitler",
];

function detectSpam(text: string): boolean {
  const lower = text.toLowerCase();
  const hasExcessiveCaps =
    (text.match(/[A-ZÇĞİÖŞÜ]/g) || []).length > text.length * 0.6 &&
    text.length > 20;
  const hasRepeatedLinks = (text.match(/https?:\/\//gi) || []).length >= 3;
  const hasLongRepeat = /(.)\1{9,}/i.test(text);
  const hasManyEmojis =
    (text.match(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}]/gu) || []).length > 15;
  return hasExcessiveCaps || hasRepeatedLinks || hasLongRepeat || hasManyEmojis;
}

function detectProfanity(text: string): boolean {
  const lower = text
    .toLowerCase()
    .replace(/[^a-zçğıöşü0-9\s]/gi, " ")
    .replace(/\s+/g, " ");
  const words = lower.split(" ");
  return words.some((w) =>
    PROFANITY_TR.some(
      (p) => w === p || w.includes(p) || w.replace(/1/g, "i").replace(/0/g, "o").includes(p)
    )
  );
}

function detectNsfw(text: string): boolean {
  const lower = text.toLowerCase();
  return NSFW_KEYWORDS.some((kw) => lower.includes(kw));
}

function detectHate(text: string): boolean {
  const lower = text.toLowerCase();
  return HATE_KEYWORDS.some((kw) => lower.includes(kw));
}

interface TextResult {
  allowed: boolean;
  flagged: boolean;
  reason?: string;
  categories?: string[];
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { text } = await req.json();
    if (!text || typeof text !== "string") {
      return new Response(
        JSON.stringify({ error: "Metin gerekli." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const categories: string[] = [];
    if (detectProfanity(text)) categories.push("profanity");
    if (detectNsfw(text)) categories.push("nsfw");
    if (detectHate(text)) categories.push("hate_speech");
    if (detectSpam(text)) categories.push("spam");

    const flagged = categories.length > 0;
    const reason = flagged
      ? `İçerik filtrelendi: ${categories.join(", ")}`
      : undefined;

    const result: TextResult = {
      allowed: !flagged,
      flagged,
      reason,
      categories: categories.length ? categories : undefined,
    };

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("moderate-text error", err);
    return new Response(
      JSON.stringify({ error: "Sunucu hatası." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

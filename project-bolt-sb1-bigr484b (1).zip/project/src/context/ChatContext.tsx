import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useRef,
  type ReactNode,
} from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Conversation, Message } from '@/types';

interface StartChatParams {
  recipientId: string;
  recipientName: string;
  recipientAvatar: string | null;
  listingId: string;
  listingTitle: string;
  listingImage: string | null;
  prefillMessage?: string;
}

interface ChatContextValue {
  isOpen: boolean;
  conversations: Conversation[];
  activeConversation: Conversation | null;
  activeMessages: Message[];
  unreadTotal: number;
  openChat: () => void;
  closeChat: () => void;
  startChat: (params: StartChatParams) => void;
  selectConversation: (otherUserId: string) => void;
  sendMessage: (text: string, imageUrl?: string | null) => Promise<void>;
  isBlocked: (otherUserId: string) => boolean;
  blockedIds: Set<string>;
  refreshBlocked: () => Promise<void>;
}

const ChatContext = createContext<ChatContextValue | undefined>(undefined);

export function ChatProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeOtherId, setActiveOtherId] = useState<string | null>(null);
  const [activeMessages, setActiveMessages] = useState<Message[]>([]);
  const [pendingStart, setPendingStart] = useState<StartChatParams | null>(null);
  const [blockedIds, setBlockedIds] = useState<Set<string>>(new Set());
  const subscriptionRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const activeConversation =
    conversations.find((c) => c.other_user_id === activeOtherId) || null;

  const fetchConversations = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('messages')
      .select(
        'id, listing_id, sender_id, recipient_id, body, image_url, created_at, read_at'
      )
      .or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`)
      .order('created_at', { ascending: false });

    if (!data) return;
    const allMessages = data as Message[];

    const convMap = new Map<string, Conversation>();
    for (const msg of allMessages) {
      const otherId = msg.sender_id === user.id ? msg.recipient_id : msg.sender_id;
      const existing = convMap.get(otherId);
      const isUnread = msg.recipient_id === user.id && msg.read_at === null;
      if (!existing) {
        convMap.set(otherId, {
          other_user_id: otherId,
          other_display_name: '',
          other_avatar_url: null,
          listing_id: msg.listing_id,
          listing_title: null,
          listing_image: null,
          last_message: msg,
          unread_count: isUnread ? 1 : 0,
        });
      } else {
        if (isUnread) existing.unread_count++;
      }
    }

    const convs = Array.from(convMap.values());

    const otherIds = convs.map((c) => c.other_user_id);
    if (otherIds.length > 0) {
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, display_name, avatar_url')
        .in('id', otherIds);
      for (const conv of convs) {
        const p = (profiles as { id: string; display_name: string; avatar_url: string | null }[] | null)?.find(
          (pr) => pr.id === conv.other_user_id
        );
        if (p) {
          conv.other_display_name = p.display_name;
          conv.other_avatar_url = p.avatar_url;
        }
      }

      const listingIds = convs
        .map((c) => c.listing_id)
        .filter((id): id is string => id !== null);
      if (listingIds.length > 0) {
        const { data: listings } = await supabase
          .from('listings')
          .select('id, title, images')
          .in('id', listingIds);
        for (const conv of convs) {
          if (conv.listing_id) {
            const l = (listings as { id: string; title: string; images: string[] }[] | null)?.find(
              (li) => li.id === conv.listing_id
            );
            if (l) {
              conv.listing_title = l.title;
              conv.listing_image = l.images?.[0] || null;
            }
          }
        }
      }
    }

    convs.sort(
      (a, b) =>
        new Date(b.last_message.created_at).getTime() -
        new Date(a.last_message.created_at).getTime()
    );
    setConversations(convs);
  }, [user]);

  const fetchMessages = useCallback(
    async (otherId: string) => {
      if (!user) return;
      const { data } = await supabase
        .from('messages')
        .select(
          'id, listing_id, sender_id, recipient_id, body, image_url, created_at, read_at'
        )
        .or(
          `and(sender_id.eq.${user.id},recipient_id.eq.${otherId}),and(sender_id.eq.${otherId},recipient_id.eq.${user.id})`
        )
        .order('created_at', { ascending: true });
      setActiveMessages((data as Message[]) || []);
    },
    [user]
  );

  const markAsRead = useCallback(
    async (otherId: string) => {
      if (!user) return;
      await supabase
        .from('messages')
        .update({ read_at: new Date().toISOString() })
        .eq('recipient_id', user.id)
        .eq('sender_id', otherId)
        .is('read_at', null);
    },
    [user]
  );

  const fetchBlockedIds = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('blocked_users')
      .select('blocked_id')
      .eq('blocker_id', user.id);
    setBlockedIds(new Set((data as { blocked_id: string }[])?.map((d) => d.blocked_id) || []));
  }, [user]);

  useEffect(() => {
    if (user) {
      fetchBlockedIds();
    } else {
      setBlockedIds(new Set());
    }
  }, [user, fetchBlockedIds]);

  useEffect(() => {
    if (!user) return;

    if (subscriptionRef.current) {
      supabase.removeChannel(subscriptionRef.current);
    }

    const channel = supabase
      .channel('messages-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `recipient_id=eq.${user.id}`,
        },
        () => {
          fetchConversations();
          if (activeOtherId) fetchMessages(activeOtherId);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `sender_id=eq.${user.id}`,
        },
        () => {
          fetchConversations();
          if (activeOtherId) fetchMessages(activeOtherId);
        }
      )
      .subscribe();

    subscriptionRef.current = channel;

    return () => {
      supabase.removeChannel(channel);
      subscriptionRef.current = null;
    };
  }, [user, fetchConversations, fetchMessages, activeOtherId]);

  useEffect(() => {
    if (activeOtherId) {
      fetchMessages(activeOtherId);
      markAsRead(activeOtherId);
    } else {
      setActiveMessages([]);
    }
  }, [activeOtherId, fetchMessages, markAsRead]);

  const openChat = useCallback(() => setIsOpen(true), []);
  const closeChat = useCallback(() => setIsOpen(false), []);

  const startChat = useCallback((params: StartChatParams) => {
    if (!user) return;
    if (blockedIds.has(params.recipientId)) {
      return;
    }
    setPendingStart(params);
    setActiveOtherId(params.recipientId);
    setIsOpen(true);
  }, [user, blockedIds]);

  useEffect(() => {
    if (!pendingStart || !user || !isOpen) return;
    const send = async () => {
      if (pendingStart.prefillMessage) {
        await supabase.from('messages').insert({
          listing_id: pendingStart.listingId,
          sender_id: user.id,
          recipient_id: pendingStart.recipientId,
          body: pendingStart.prefillMessage,
        });
      }
      fetchConversations();
      fetchMessages(pendingStart.recipientId);
    };
    send();
    setPendingStart(null);
  }, [pendingStart, user, isOpen, fetchConversations, fetchMessages]);

  const selectConversation = useCallback(
    (otherUserId: string) => {
      setActiveOtherId(otherUserId);
    },
    []
  );

  const sendMessage = useCallback(
    async (text: string, imageUrl: string | null = null) => {
      if (!user || !activeOtherId || !text.trim()) return;
      if (blockedIds.has(activeOtherId)) return;
      const { data } = await supabase
        .from('messages')
        .insert({
          listing_id: activeConversation?.listing_id || null,
          sender_id: user.id,
          recipient_id: activeOtherId,
          body: text.trim(),
          image_url: imageUrl,
        })
        .select(
          'id, listing_id, sender_id, recipient_id, body, image_url, created_at, read_at'
        )
        .single();
      if (data) {
        setActiveMessages((prev) => [...prev, data as Message]);
        fetchConversations();
      }
    },
    [user, activeOtherId, activeConversation, fetchConversations]
  );

  const isBlockedFn = useCallback(
    (otherUserId: string) => blockedIds.has(otherUserId),
    [blockedIds]
  );

  const unreadTotal = conversations.reduce((sum, c) => sum + c.unread_count, 0);

  return (
    <ChatContext.Provider
      value={{
        isOpen,
        conversations,
        activeConversation,
        activeMessages,
        unreadTotal,
        openChat,
        closeChat,
        startChat,
        selectConversation,
        sendMessage,
        isBlocked: isBlockedFn,
        blockedIds,
        refreshBlocked: fetchBlockedIds,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error('useChat must be used within ChatProvider');
  return ctx;
}

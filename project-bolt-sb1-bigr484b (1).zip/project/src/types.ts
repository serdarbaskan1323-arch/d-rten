export type Category = 'Regular' | 'Silver' | 'Premium' | 'Chase' | 'STH' | 'TH';

export type Condition =
  | 'Sıfır / Sorunsuz'
  | 'Koruma Kılıflı / Kablı'
  | 'Blisteri Hasarlı / Yırtık'
  | 'Kutusu Açık';

export const CONDITIONS: Condition[] = [
  'Sıfır / Sorunsuz',
  'Koruma Kılıflı / Kablı',
  'Blisteri Hasarlı / Yırtık',
  'Kutusu Açık',
];

export type ListingStatus = 'active' | 'passive' | 'sold';

export interface Profile {
  id: string;
  display_name: string;
  phone: string | null;
  city: string | null;
  district: string | null;
  avatar_url: string | null;
  role: 'user' | 'admin';
  created_at: string;
  updated_at: string;
}

export interface Listing {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  category: Category;
  price: number | null;
  is_trade: boolean;
  city: string | null;
  district: string | null;
  condition: Condition | null;
  images: string[];
  featured: boolean;
  status: ListingStatus;
  views: number;
  created_at: string;
  updated_at: string;
}

export interface ListingWithProfile extends Listing {
  profiles: Profile | null;
}

export interface Message {
  id: string;
  listing_id: string | null;
  sender_id: string;
  recipient_id: string;
  body: string;
  image_url: string | null;
  created_at: string;
  read_at: string | null;
}

export interface Conversation {
  other_user_id: string;
  other_display_name: string;
  other_avatar_url: string | null;
  listing_id: string | null;
  listing_title: string | null;
  listing_image: string | null;
  last_message: Message;
  unread_count: number;
}

export interface Feedback {
  id: string;
  user_id: string | null;
  display_name: string | null;
  message: string;
  ai_flagged: boolean;
  ai_reason: string | null;
  created_at: string;
}

export interface FilterState {
  query: string;
  category: Category | 'all';
  city: string | 'all';
  condition: Condition | 'all';
}

export interface Offer {
  id: string;
  listing_id: string;
  bidder_id: string;
  amount: number;
  status: 'pending' | 'accepted' | 'rejected';
  created_at: string;
}

export interface OfferWithProfile extends Offer {
  profiles: Profile | null;
}

export interface Comment {
  id: string;
  listing_id: string;
  user_id: string;
  body: string;
  created_at: string;
}

export interface CommentWithProfile extends Comment {
  profiles: Profile | null;
}

export interface Report {
  id: string;
  reporter_id: string;
  reported_user_id: string;
  listing_id: string | null;
  reason: string;
  description: string | null;
  status: 'pending' | 'resolved' | 'dismissed';
  created_at: string;
}

export interface ReportWithDetails extends Report {
  reporter_profile: Profile | null;
  reported_profile: Profile | null;
  listing: Listing | null;
}

export interface BlockedUser {
  blocker_id: string;
  blocked_id: string;
  created_at: string;
}

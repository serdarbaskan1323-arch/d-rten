import { useEffect, useState, useCallback } from 'react';
import {
  ArrowLeft,
  MapPin,
  Phone,
  MessageSquare,
  RefreshCw,
  Eye,
  Share2,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Tag,
  Check,
  X as XIcon,
  Send,
  MessageCircle,
  Loader2,
  AlertCircle,
  Flag,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useChat } from '@/context/ChatContext';
import { useToast } from '@/context/ToastContext';
import { sanitizeText } from '@/lib/sanitize';
import { containsProfanity } from '@/lib/profanity';
import type { ListingWithProfile, OfferWithProfile, CommentWithProfile } from '@/types';
import { CategoryBadge } from '@/components/CategoryBadge';
import { ConditionBadge } from '@/components/ConditionBadge';
import { TrustBadgeMini } from '@/components/TrustBadge';
import { ReportModal } from '@/components/ReportModal';
import { formatPrice, formatRelativeDate, formatLocation, buildGoogleMapsUrl } from '@/constants';

interface Props {
  listingId: string;
  onBack: () => void;
  onRequireAuth: () => void;
}

export function ListingDetailPage({ listingId, onBack, onRequireAuth }: Props) {
  const { user } = useAuth();
  const { startChat } = useChat();
  const { showToast } = useToast();
  const [listing, setListing] = useState<ListingWithProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeImg, setActiveImg] = useState(0);
  const [copied, setCopied] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);

  // Offers state
  const [offers, setOffers] = useState<OfferWithProfile[]>([]);
  const [offerAmount, setOfferAmount] = useState('');
  const [offerError, setOfferError] = useState<string | null>(null);
  const [offerSubmitting, setOfferSubmitting] = useState(false);

  // Comments state
  const [comments, setComments] = useState<CommentWithProfile[]>([]);
  const [commentBody, setCommentBody] = useState('');
  const [commentSubmitting, setCommentSubmitting] = useState(false);

  const fetchOffers = useCallback(async () => {
    const { data } = await supabase
      .from('offers')
      .select('*, profiles!offers_profiles_id_fkey(*)')
      .eq('listing_id', listingId)
      .order('created_at', { ascending: false });
    setOffers((data as OfferWithProfile[]) || []);
  }, [listingId]);

  const fetchComments = useCallback(async () => {
    const { data } = await supabase
      .from('comments')
      .select('*, profiles!comments_profiles_id_fkey(*)')
      .eq('listing_id', listingId)
      .order('created_at', { ascending: true });
    setComments((data as CommentWithProfile[]) || []);
  }, [listingId]);

  useEffect(() => {
    setLoading(true);
    setActiveImg(0);
    supabase
      .from('listings')
      .select('*, profiles!listings_profiles_id_fkey(*)')
      .eq('id', listingId)
      .maybeSingle()
      .then(({ data }) => {
        setListing(data as ListingWithProfile | null);
        setLoading(false);
      });
    supabase
      .from('listings')
      .update({ views: (listing?.views ?? 0) + 1 })
      .eq('id', listingId)
      .then(() => {});
    fetchOffers();
    fetchComments();
  }, [listingId, listing?.views, fetchOffers, fetchComments]);

  const profile = listing?.profiles;
  const mapsUrl = buildGoogleMapsUrl(listing?.city, listing?.district);

  const handleShare = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({ title: listing?.title, url });
      } else {
        await navigator.clipboard.writeText(url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch {
      // user cancelled
    }
  };

  const handleMessageClick = () => {
    if (!user) {
      onRequireAuth();
      return;
    }
    if (!listing) return;
    startChat({
      recipientId: listing.user_id,
      recipientName: listing.profiles?.display_name || 'Satıcı',
      recipientAvatar: listing.profiles?.avatar_url || null,
      listingId: listing.id,
      listingTitle: listing.title,
      listingImage: listing.images?.[0] || null,
      prefillMessage: `Merhaba, "${listing.title}" ilanınız için yazıyorum.`,
    });
  };

  const handlePlaceOffer = async () => {
    setOfferError(null);
    if (!user) {
      onRequireAuth();
      return;
    }
    if (!offerAmount || parseFloat(offerAmount) <= 0) {
      setOfferError('Geçerli bir teklif girin.');
      return;
    }
    setOfferSubmitting(true);
    const { error } = await supabase.from('offers').insert({
      listing_id: listingId,
      bidder_id: user.id,
      amount: parseFloat(offerAmount),
    });
    setOfferSubmitting(false);
    if (error) {
      setOfferError('Teklif gönderilemedi.');
      return;
    }
    setOfferAmount('');
    fetchOffers();
  };

  const handleOfferAction = async (offerId: string, status: 'accepted' | 'rejected') => {
    await supabase.from('offers').update({ status }).eq('id', offerId);
    setOffers((prev) => prev.map((o) => (o.id === offerId ? { ...o, status } : o)));
  };

  const handlePostComment = async () => {
    if (!user) {
      onRequireAuth();
      return;
    }
    if (!commentBody.trim()) return;
    if (containsProfanity(commentBody)) {
      showToast('Yorumunuz uygunsuz içerik tespit edildiği için engellendi.', 'error');
      return;
    }
    setCommentSubmitting(true);
    const { data, error } = await supabase
      .from('comments')
      .insert({
        listing_id: listingId,
        user_id: user.id,
        body: sanitizeText(commentBody),
      })
      .select('*, profiles!comments_profiles_id_fkey(*)')
      .single();
    setCommentSubmitting(false);
    if (error) return;
    if (data) {
      setComments((prev) => [...prev, data as CommentWithProfile]);
    }
    setCommentBody('');
  };

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-orange-500 border-t-transparent" />
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <h2 className="text-xl font-bold text-white">İlan bulunamadı</h2>
        <button onClick={onBack} className="mt-4 text-sm font-semibold text-orange-400 hover:text-orange-300">
          ← Geri dön
        </button>
      </div>
    );
  }

  const images = listing.images.length > 0 ? listing.images : [];
  const isOwnListing = user?.id === listing.user_id;
  const hasPrice = listing.price !== null && listing.price !== undefined;
  const pendingOffers = offers.filter((o) => o.status === 'pending');
  const otherOffers = offers.filter((o) => o.status !== 'pending');

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 animate-fade-in sm:px-6">
      <button
        onClick={onBack}
        className="mb-4 inline-flex items-center gap-1.5 text-sm font-semibold text-slate-400 transition hover:text-white"
      >
        <ArrowLeft className="h-4 w-4" />
        Geri
      </button>

      <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        {/* Gallery */}
        <div className="space-y-6">
          <div>
            <div className="relative aspect-[4/3] overflow-hidden rounded-2xl bg-slate-900">
              {images.length > 0 ? (
                <img src={images[activeImg]} alt={listing.title} className="h-full w-full object-contain p-3" />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-6xl">🏎️</div>
              )}
              {images.length > 1 && (
                <>
                  <button
                    onClick={() => setActiveImg((i) => (i === 0 ? images.length - 1 : i - 1))}
                    className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-2 text-white transition hover:bg-black/70"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => setActiveImg((i) => (i === images.length - 1 ? 0 : i + 1))}
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/50 p-2 text-white transition hover:bg-black/70"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </button>
                  <div className="absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-black/60 px-3 py-1 text-xs text-white">
                    {activeImg + 1} / {images.length}
                  </div>
                </>
              )}
              {listing.featured && (
                <div className="absolute right-3 top-3 rounded-full bg-gradient-flame px-3 py-1 text-xs font-bold text-white shadow-lg">
                  VİTRİN
                </div>
              )}
            </div>

            {images.length > 1 && (
              <div className="mt-3 flex gap-2 overflow-x-auto scrollbar-hide">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImg(i)}
                    className={`h-16 w-20 shrink-0 overflow-hidden rounded-lg border-2 transition ${
                      activeImg === i ? 'border-orange-500' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="h-full w-full object-contain p-0.5" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Description */}
          {listing.description && (
            <div className="rounded-2xl glass-card p-5">
              <h2 className="mb-2 text-sm font-bold uppercase tracking-wider text-slate-400">Açıklama</h2>
              <p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-200">
                {listing.description}
              </p>
            </div>
          )}

          {/* Offers section — visible to all, actionable for owner */}
          {hasPrice && (
            <div className="rounded-2xl glass-card p-5">
              <h2 className="mb-4 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-400">
                <Tag className="h-4 w-4 text-orange-500" />
                {isOwnListing ? 'Gelen Teklifler' : 'Teklif Ver'}
              </h2>

              {isOwnListing ? (
                <>
                  {pendingOffers.length === 0 && otherOffers.length === 0 ? (
                    <p className="py-6 text-center text-sm text-slate-500">
                      Henüz teklif gelmedi.
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {pendingOffers.map((offer) => (
                        <OfferRow
                          key={offer.id}
                          offer={offer}
                          onAccept={() => handleOfferAction(offer.id, 'accepted')}
                          onReject={() => handleOfferAction(offer.id, 'rejected')}
                        />
                      ))}
                      {otherOffers.length > 0 && (
                        <div className="border-t border-slate-700/40 pt-3">
                          <p className="mb-2 text-xs font-semibold text-slate-500">Geçmiş Teklifler</p>
                          <div className="space-y-2">
                            {otherOffers.map((offer) => (
                              <OfferRow key={offer.id} offer={offer} />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </>
              ) : (
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={offerAmount}
                      onChange={(e) => setOfferAmount(e.target.value)}
                      placeholder="Teklif tutarı (TL)"
                      min="0"
                      className="flex-1 rounded-xl border border-slate-700/50 bg-slate-900/60 px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
                    />
                    <button
                      onClick={handlePlaceOffer}
                      disabled={offerSubmitting || !offerAmount}
                      className="rounded-xl bg-gradient-flame px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 disabled:opacity-50 active:scale-[0.98]"
                    >
                      {offerSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Teklif Et'}
                    </button>
                  </div>
                  {offerError && (
                    <p className="flex items-center gap-1.5 text-xs text-red-400">
                      <AlertCircle className="h-3.5 w-3.5" />
                      {offerError}
                    </p>
                  )}
                  {pendingOffers.length > 0 && (
                    <div className="space-y-2 border-t border-slate-700/40 pt-3">
                      <p className="text-xs font-semibold text-slate-500">Gelen Teklifler ({pendingOffers.length})</p>
                      {pendingOffers.map((offer) => (
                        <OfferRow key={offer.id} offer={offer} />
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Comments / Q&A section */}
          <div className="rounded-2xl glass-card p-5">
            <h2 className="mb-4 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-400">
              <MessageCircle className="h-4 w-4 text-orange-500" />
              Yorumlar & Sorular ({comments.length})
            </h2>

            {comments.length === 0 ? (
              <p className="py-4 text-center text-sm text-slate-500">
                Henüz yorum yok. İlk yorumu sen yap!
              </p>
            ) : (
              <div className="space-y-4">
                {comments.map((comment) => {
                  const cProfile = comment.profiles;
                  const isOwnComment = comment.user_id === user?.id;
                  return (
                    <div key={comment.id} className="flex gap-3">
                      {cProfile?.avatar_url ? (
                        <img src={cProfile.avatar_url} alt="" className="h-8 w-8 shrink-0 rounded-full object-cover" />
                      ) : (
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-flame text-xs font-bold text-white">
                          {(cProfile?.display_name || '?').charAt(0).toUpperCase()}
                        </span>
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="rounded-xl bg-slate-800/60 px-3.5 py-2.5">
                          <div className="mb-1 flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-200">
                              {cProfile?.display_name || 'Anonim'}
                            </span>
                            {isOwnComment && (
                              <span className="rounded bg-orange-500/20 px-1.5 py-0.5 text-[9px] font-semibold text-orange-400">
                                SİZ
                              </span>
                            )}
                          </div>
                          <p className="whitespace-pre-wrap break-words text-sm text-slate-300">
                            {comment.body}
                          </p>
                        </div>
                        <p className="mt-1 pl-1 text-[10px] text-slate-600">
                          {formatRelativeDate(comment.created_at)}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Comment input */}
            {user ? (
              <div className="mt-4 flex gap-2 border-t border-slate-700/40 pt-4">
                <input
                  type="text"
                  value={commentBody}
                  onChange={(e) => setCommentBody(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handlePostComment();
                  }}
                  placeholder="Yorum veya soru yazın..."
                  maxLength={500}
                  className="flex-1 rounded-xl border border-slate-700/50 bg-slate-900/60 px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
                />
                <button
                  onClick={handlePostComment}
                  disabled={commentSubmitting || !commentBody.trim()}
                  className="rounded-xl bg-gradient-flame px-3 py-2.5 text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 disabled:opacity-50 active:scale-95"
                >
                  {commentSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </button>
              </div>
            ) : (
              <button
                onClick={() => onRequireAuth()}
                className="mt-4 w-full rounded-xl border border-slate-700/50 py-2.5 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/40"
              >
                Yorum yapmak için giriş yapın
              </button>
            )}
          </div>
        </div>

        {/* Right column — info & seller */}
        <div className="space-y-4">
          <div className="rounded-2xl glass-card p-5">
            <div className="mb-3 flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <CategoryBadge category={listing.category} size="md" />
              </div>
              <button
                onClick={handleShare}
                className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-white"
                title="Paylaş"
              >
                {copied ? <CheckCircle2 className="h-5 w-5 text-green-400" /> : <Share2 className="h-5 w-5" />}
              </button>
            </div>

            <h1 className="text-xl font-extrabold leading-tight text-white sm:text-2xl">
              {listing.title}
            </h1>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              {hasPrice && (
                <span className="text-2xl font-extrabold text-orange-400">
                  {formatPrice(listing.price)}
                </span>
              )}
              {listing.is_trade && (
                <span className="inline-flex items-center gap-1.5 rounded-lg bg-blue-500/15 px-3 py-1.5 text-sm font-bold text-blue-400">
                  <RefreshCw className="h-4 w-4" />
                  Takaslı
                </span>
              )}
            </div>

            {listing.condition && (
              <div className="mt-3">
                <ConditionBadge condition={listing.condition} size="md" />
              </div>
            )}

            <div className="mt-4 space-y-2 border-t border-slate-700/40 pt-4 text-sm">
              <div className="flex items-center gap-2 text-slate-300">
                <MapPin className="h-4 w-4 text-orange-500" />
                <span>{formatLocation(listing.city, listing.district)}</span>
              </div>
              {mapsUrl && (
                <a
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ml-6 inline-flex items-center gap-1.5 text-xs font-semibold text-orange-400 transition hover:text-orange-300"
                >
                  <MapPin className="h-3.5 w-3.5" />
                  Google Maps'te Gör
                </a>
              )}
              <div className="flex items-center gap-2 text-slate-400">
                <Eye className="h-4 w-4" />
                <span>{listing.views} görüntülenme</span>
              </div>
              <p className="text-xs text-slate-500">{formatRelativeDate(listing.created_at)} ilan verildi</p>
            </div>
          </div>

          {/* Seller */}
          <div className="rounded-2xl glass-card p-5">
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-slate-400">İlan Sahibi</h2>
            <div className="flex items-center gap-3">
              {profile?.avatar_url ? (
                <img src={profile.avatar_url} alt="" className="h-11 w-11 rounded-full object-cover" />
              ) : (
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-flame text-base font-bold text-white">
                  {(profile?.display_name || '?').charAt(0).toUpperCase()}
                </span>
              )}
              <div>
                <p className="text-sm font-bold text-white">{profile?.display_name || 'Anonim'}</p>
                <TrustBadgeMini />
              </div>
            </div>

            <div className="mt-4 space-y-2">
              <button
                onClick={handleMessageClick}
                disabled={isOwnListing}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-flame py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 active:scale-[0.98] disabled:opacity-50"
              >
                <MessageSquare className="h-4 w-4" />
                Satıcıya Mesaj Gönder
              </button>
              {!isOwnListing && (
                <button
                  onClick={() => {
                    if (!user) {
                      onRequireAuth();
                      return;
                    }
                    setReportOpen(true);
                  }}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-500/30 bg-red-500/10 py-2.5 text-sm font-bold text-red-400 transition hover:bg-red-500/20 active:scale-[0.98]"
                >
                  <Flag className="h-4 w-4" />
                  Şikayet Et
                </button>
              )}
              {isOwnListing && (
                <p className="text-center text-xs text-slate-500">Bu kendi ilanınız</p>
              )}
              {profile?.phone && !isOwnListing && (
                <a
                  href={`tel:${profile.phone}`}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-slate-700/50 py-2.5 text-sm font-bold text-slate-200 transition hover:bg-slate-700/40"
                >
                  <Phone className="h-4 w-4" />
                  Ara / Telefon
                </a>
              )}
            </div>
          </div>
        </div>
      </div>

      <ReportModal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        reportedUserId={listing.user_id}
        reportedUserName={profile?.display_name || 'Satıcı'}
        listingId={listing.id}
        listingTitle={listing.title}
      />
    </div>
  );
}

function OfferRow({
  offer,
  onAccept,
  onReject,
}: {
  offer: OfferWithProfile;
  onAccept?: () => void;
  onReject?: () => void;
}) {
  const oProfile = offer.profiles;
  const statusStyle =
    offer.status === 'accepted'
      ? 'bg-green-500/15 text-green-400'
      : offer.status === 'rejected'
      ? 'bg-red-500/15 text-red-400'
      : 'bg-amber-500/15 text-amber-400';
  const statusLabel =
    offer.status === 'accepted' ? 'Kabul Edildi' : offer.status === 'rejected' ? 'Reddedildi' : 'Beklemede';

  return (
    <div className="flex items-center gap-3 rounded-xl bg-slate-800/40 px-3 py-2.5">
      {oProfile?.avatar_url ? (
        <img src={oProfile.avatar_url} alt="" className="h-8 w-8 shrink-0 rounded-full object-cover" />
      ) : (
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-flame text-xs font-bold text-white">
          {(oProfile?.display_name || '?').charAt(0).toUpperCase()}
        </span>
      )}
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs font-semibold text-slate-200">
          {oProfile?.display_name || 'Anonim'}
        </p>
        <p className="text-sm font-extrabold text-orange-400">
          {formatPrice(offer.amount)}
        </p>
      </div>
      {onAccept && onReject && offer.status === 'pending' ? (
        <div className="flex shrink-0 gap-1.5">
          <button
            onClick={onAccept}
            className="inline-flex items-center gap-1 rounded-lg bg-green-500/15 px-2.5 py-1.5 text-xs font-bold text-green-400 transition hover:bg-green-500/25"
          >
            <Check className="h-3.5 w-3.5" />
            Kabul Et
          </button>
          <button
            onClick={onReject}
            className="inline-flex items-center gap-1 rounded-lg bg-red-500/15 px-2.5 py-1.5 text-xs font-bold text-red-400 transition hover:bg-red-500/25"
          >
            <XIcon className="h-3.5 w-3.5" />
            Reddet
          </button>
        </div>
      ) : (
        <span className={`shrink-0 rounded-md px-2 py-1 text-[10px] font-bold ${statusStyle}`}>
          {statusLabel}
        </span>
      )}
    </div>
  );
}

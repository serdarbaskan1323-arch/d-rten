import { useEffect, useState, useCallback } from 'react';
import { Loader2, Search as SearchIcon, SlidersHorizontal, X, Plus, PackageOpen } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useChat } from '@/context/ChatContext';
import type { ListingWithProfile, FilterState } from '@/types';
import { ListingRow } from '@/components/ListingRow';
import { CATEGORY_LABELS } from '@/constants';

interface Props {
  filter: FilterState;
  onFilterChange: (f: FilterState) => void;
  onOpenFilter: () => void;
  onOpenListing: (id: string) => void;
  onAddListing: () => void;
}

const PAGE_SIZE = 20;

export function SearchPage({ filter, onFilterChange, onOpenFilter, onOpenListing, onAddListing }: Props) {
  const [results, setResults] = useState<ListingWithProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(0);
  const { blockedIds } = useChat();

  const buildQuery = useCallback((pageNum: number) => {
    let q = supabase
      .from('listings')
      .select('*, profiles!listings_profiles_id_fkey(*)')
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (filter.query.trim()) {
      q = q.or(`title.ilike.%${filter.query.trim()}%,description.ilike.%${filter.query.trim()}%`);
    }
    if (filter.category !== 'all') {
      q = q.eq('category', filter.category);
    }
    if (filter.city !== 'all') {
      q = q.eq('city', filter.city);
    }
    if (filter.condition !== 'all') {
      q = q.eq('condition', filter.condition);
    }
    return q.range(pageNum * PAGE_SIZE, pageNum * PAGE_SIZE + PAGE_SIZE - 1);
  }, [filter]);

  const fetchResults = useCallback(
    async (pageNum: number) => {
      const { data } = await buildQuery(pageNum);
      const rows = ((data as ListingWithProfile[]) || []).filter(
        (l) => !blockedIds.has(l.user_id)
      );
      if (pageNum === 0) setResults(rows);
      else setResults((prev) => [...prev, ...rows]);
      setHasMore(rows.length === PAGE_SIZE);
    },
    [buildQuery]
  );

  useEffect(() => {
    setLoading(true);
    setPage(0);
    fetchResults(0).finally(() => setLoading(false));
  }, [filter, fetchResults]);

  const loadMore = async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    const next = page + 1;
    await fetchResults(next);
    setPage(next);
    setLoadingMore(false);
  };

  const hasActiveFilters =
    filter.query.trim() || filter.category !== 'all' || filter.city !== 'all' || filter.condition !== 'all';

  const clearFilters = () => {
    onFilterChange({ query: '', category: 'all', city: 'all', condition: 'all' });
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 animate-fade-in sm:px-6">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-extrabold text-white">İlan Ara</h1>
        <button
          onClick={onOpenFilter}
          className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-flame px-4 py-2 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110"
        >
          <SlidersHorizontal className="h-4 w-4" />
          Filtrele
        </button>
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        {filter.query.trim() && (
          <FilterChip label={`"${filter.query}"`} onRemove={() => onFilterChange({ ...filter, query: '' })} />
        )}
        {filter.category !== 'all' && (
          <FilterChip
            label={CATEGORY_LABELS[filter.category]}
            onRemove={() => onFilterChange({ ...filter, category: 'all' })}
          />
        )}
        {filter.city !== 'all' && (
          <FilterChip label={filter.city} onRemove={() => onFilterChange({ ...filter, city: 'all' })} />
        )}
        {filter.condition !== 'all' && (
          <FilterChip label={filter.condition} onRemove={() => onFilterChange({ ...filter, condition: 'all' })} />
        )}
        {hasActiveFilters && (
          <button
            onClick={clearFilters}
            className="text-xs font-semibold text-slate-400 underline transition hover:text-orange-400"
          >
            Filtreleri Temizle
        </button>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
        </div>
      ) : results.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl glass-card py-16 text-center animate-slide-up">
          {hasActiveFilters ? (
            <>
              <SearchIcon className="mb-3 h-10 w-10 text-slate-600" />
              <h3 className="text-lg font-bold text-white">Sonuç bulunamadı</h3>
              <p className="mt-1 max-w-sm text-sm text-slate-400">
                Arama kriterlerinize uygun ilan yok. Filtreleri değiştirmeyi deneyin.
              </p>
              <button
                onClick={clearFilters}
                className="mt-4 rounded-xl border border-slate-700/50 px-4 py-2 text-sm font-semibold text-slate-200 transition hover:bg-slate-700/40"
              >
                Filtreleri Temizle
              </button>
            </>
          ) : (
            <>
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-orange-500/10 border border-orange-500/20">
                <PackageOpen className="h-8 w-8 text-orange-500" />
              </div>
              <h3 className="text-lg font-bold text-white">Henüz ilan bulunmuyor</h3>
              <p className="mt-1.5 max-w-sm text-sm text-slate-400">
                İlk ilanı sen ver! Hot Wheels ve diecast koleksiyonundan parçalarını paylaş.
              </p>
              <button
                onClick={onAddListing}
                className="mt-5 inline-flex items-center gap-2 rounded-xl bg-gradient-flame px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 active:scale-95"
              >
                <Plus className="h-4 w-4" />
                İlan Ver
              </button>
            </>
          )}
        </div>
      ) : (
        <>
          <p className="mb-3 text-sm text-slate-400">
            <span className="font-bold text-orange-400">{results.length}</span> ilan bulundu
          </p>
          <div className="space-y-2.5">
            {results.map((l) => (
              <ListingRow key={l.id} listing={l} onClick={() => onOpenListing(l.id)} />
            ))}
          </div>
          {hasMore && (
            <div className="mt-6 flex justify-center">
              <button
                onClick={loadMore}
                disabled={loadingMore}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-700/50 glass px-6 py-2.5 text-sm font-semibold text-slate-200 transition hover:bg-slate-700/40 disabled:opacity-50"
              >
                {loadingMore ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Yükleniyor...
                  </>
                ) : (
                  'Daha Fazla Yükle'
                )}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function FilterChip({ label, onRemove }: { label: string; onRemove: () => void }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-orange-500/30 bg-orange-500/10 px-3 py-1 text-xs font-semibold text-orange-300">
      {label}
      <button onClick={onRemove} className="transition hover:text-orange-100">
        <X className="h-3 w-3" />
      </button>
    </span>
  );
}

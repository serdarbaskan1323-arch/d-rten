import { useEffect, useState, useCallback } from 'react';
import {
  Phone,
  MapPin,
  Edit2,
  Trash2,
  Power,
  PowerOff,
  Check,
  X,
  Loader2,
  Package,
  LogOut,
  Plus,
  PackageOpen,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Listing, Profile, Condition } from '@/types';
import { CategoryBadge } from '@/components/CategoryBadge';
import { ConditionBadge } from '@/components/ConditionBadge';
import { TrustBadgeMini } from '@/components/TrustBadge';
import { TURKISH_CITIES, formatPrice, formatRelativeDate, formatLocation, buildGoogleMapsUrl, CONDITIONS } from '@/constants';
import { sanitizeText } from '@/lib/sanitize';
import type { Category } from '@/types';

interface Props {
  onOpenListing: (id: string) => void;
  onAddListing: () => void;
}

export function ProfilePage({ onOpenListing, onAddListing }: Props) {
  const { user, profile, updateProfile, signOut } = useAuth();
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingProfile, setEditingProfile] = useState(false);
  const [editForm, setEditForm] = useState<Partial<Profile>>({});
  const [savingProfile, setSavingProfile] = useState(false);
  const [editingListing, setEditingListing] = useState<Listing | null>(null);

  const fetchListings = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('listings')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setListings((data as Listing[]) || []);
  }, [user]);

  useEffect(() => {
    if (user) {
      setLoading(true);
      fetchListings().finally(() => setLoading(false));
    }
  }, [user, fetchListings]);

  useEffect(() => {
    if (profile) {
      setEditForm({
        display_name: profile.display_name,
        phone: profile.phone,
        city: profile.city,
        district: profile.district,
      });
    }
  }, [profile]);

  const handleSaveProfile = async () => {
    setSavingProfile(true);
    await updateProfile({
      display_name: sanitizeText(editForm.display_name || ''),
      phone: sanitizeText(editForm.phone || '') || null,
      city: editForm.city || null,
      district: sanitizeText(editForm.district || '') || null,
    });
    setSavingProfile(false);
    setEditingProfile(false);
  };

  const handleDeleteListing = async (id: string) => {
    if (!confirm('Bu ilanı silmek istediğinize emin misiniz?')) return;
    await supabase.from('listings').delete().eq('id', id);
    setListings((prev) => prev.filter((l) => l.id !== id));
  };

  const handleToggleStatus = async (listing: Listing) => {
    const newStatus = listing.status === 'active' ? 'passive' : 'active';
    await supabase.from('listings').update({ status: newStatus }).eq('id', listing.id);
    setListings((prev) =>
      prev.map((l) => (l.id === listing.id ? { ...l, status: newStatus } : l))
    );
  };

  const handleUpdateListing = async () => {
    if (!editingListing) return;
    await supabase
      .from('listings')
      .update({
        title: sanitizeText(editingListing.title),
        description: sanitizeText(editingListing.description) || null,
        category: editingListing.category,
        price: editingListing.price,
        is_trade: editingListing.is_trade,
        city: editingListing.city,
        district: sanitizeText(editingListing.district) || null,
        condition: editingListing.condition,
      })
      .eq('id', editingListing.id);
    setListings((prev) =>
      prev.map((l) => (l.id === editingListing.id ? editingListing : l))
    );
    setEditingListing(null);
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <p className="text-slate-400">Profili görüntülemek için giriş yapın.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-6 animate-fade-in sm:px-6">
      {/* Profile card */}
      <div className="mb-6 rounded-2xl glass-card p-5">
        <div className="flex items-center gap-4">
          {profile?.avatar_url ? (
            <img src={profile.avatar_url} alt="" className="h-16 w-16 rounded-full object-cover" />
          ) : (
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-flame text-2xl font-bold text-white">
              {(profile?.display_name || user.email || '?').charAt(0).toUpperCase()}
            </span>
          )}
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-extrabold text-white">
                {profile?.display_name || 'Kullanıcı'}
              </h1>
              <TrustBadgeMini />
            </div>
            <p className="text-sm text-slate-400">{user.email}</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setEditingProfile((v) => !v)}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-700/50 px-3 py-2 text-sm font-semibold text-slate-200 transition hover:bg-slate-700/40"
            >
              <Edit2 className="h-4 w-4" />
              Düzenle
            </button>
            <button
              onClick={signOut}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-700/50 px-3 py-2 text-sm font-semibold text-slate-300 transition hover:border-red-500/40 hover:text-red-400"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>

        {editingProfile && (
          <div className="mt-5 space-y-3 rounded-xl border border-slate-700/40 bg-slate-900/40 p-4 animate-slide-up">
            <div className="grid gap-3 sm:grid-cols-2">
              <ProfileField label="Görünen Ad" value={editForm.display_name || ''} onChange={(v) => setEditForm({ ...editForm, display_name: v })} />
              <ProfileField label="Telefon" value={editForm.phone || ''} onChange={(v) => setEditForm({ ...editForm, phone: v })} icon={<Phone className="h-4 w-4" />} />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-semibold text-slate-400">Şehir</label>
                <select
                  value={editForm.city || ''}
                  onChange={(e) => setEditForm({ ...editForm, city: e.target.value })}
                  className="w-full rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-orange-500/60"
                >
                  <option value="">Şehir seçin</option>
                  {TURKISH_CITIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <ProfileField label="İlçe / Semt" value={editForm.district || ''} onChange={(v) => setEditForm({ ...editForm, district: v })} />
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleSaveProfile}
                disabled={savingProfile}
                className="inline-flex items-center gap-1.5 rounded-lg bg-gradient-flame px-4 py-2 text-sm font-bold text-white transition hover:brightness-110 disabled:opacity-50"
              >
                {savingProfile ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                Kaydet
              </button>
              <button
                onClick={() => setEditingProfile(false)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700/50 px-4 py-2 text-sm font-semibold text-slate-300 transition hover:bg-slate-700/40"
              >
                <X className="h-4 w-4" />
                İptal
              </button>
            </div>
          </div>
        )}

        {!editingProfile && (
          <div className="mt-4 flex flex-wrap gap-4 border-t border-slate-700/40 pt-4 text-sm">
            {profile?.phone && (
              <div className="flex items-center gap-1.5 text-slate-300">
                <Phone className="h-4 w-4 text-orange-500" />
                {profile.phone}
              </div>
            )}
            {(profile?.city || profile?.district) && (() => {
              const mapsUrl = buildGoogleMapsUrl(profile?.city, profile?.district);
              return mapsUrl ? (
                <a
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-slate-300 transition hover:text-orange-400"
                >
                  <MapPin className="h-4 w-4 text-orange-500" />
                  {formatLocation(profile.city, profile.district)}
                </a>
              ) : (
                <div className="flex items-center gap-1.5 text-slate-300">
                  <MapPin className="h-4 w-4 text-orange-500" />
                  {formatLocation(profile.city, profile.district)}
                </div>
              );
            })()}
          </div>
        )}
      </div>

      {/* Listings */}
      <div className="mb-4 flex items-center gap-2">
        <Package className="h-5 w-5 text-orange-500" />
        <h2 className="text-lg font-bold text-white">İlanlarım</h2>
        <span className="rounded-full bg-slate-800 px-2 py-0.5 text-xs font-semibold text-slate-400">
          {listings.length}
        </span>
      </div>

      {listings.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl glass-card py-12 text-center animate-slide-up">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-orange-500/10 border border-orange-500/20">
            <PackageOpen className="h-8 w-8 text-orange-500" />
          </div>
          <p className="text-slate-300 font-semibold">Henüz ilan vermediniz</p>
          <p className="mt-1 text-sm text-slate-400">İlk ilanınızı vererek başlayın.</p>
          <button
            onClick={onAddListing}
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-gradient-flame px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 active:scale-95"
          >
            <Plus className="h-4 w-4" />
            İlan Ver
          </button>
        </div>
      ) : (
        <div className="space-y-2.5">
          {listings.map((listing) => (
            <div key={listing.id} className="flex items-center gap-3 rounded-xl glass-card p-3">
              <button
                onClick={() => onOpenListing(listing.id)}
                className="relative h-16 w-20 shrink-0 overflow-hidden rounded-lg bg-slate-800"
              >
                {listing.images[0] ? (
                  <img src={listing.images[0]} alt="" className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-2xl">🏎️</div>
                )}
              </button>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="truncate text-sm font-bold text-slate-100">{listing.title}</h3>
                  <CategoryBadge category={listing.category} />
                  {listing.condition && <ConditionBadge condition={listing.condition} />}
                </div>
                <div className="mt-0.5 flex items-center gap-3 text-xs text-slate-400">
                  {listing.is_trade ? (
                    <span className="font-bold text-blue-400">Takas</span>
                  ) : (
                    <span className="font-bold text-orange-400">{formatPrice(listing.price)}</span>
                  )}
                  <span>{formatRelativeDate(listing.created_at)}</span>
                  <span className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold ${
                    listing.status === 'active'
                      ? 'bg-green-500/15 text-green-400'
                      : listing.status === 'passive'
                      ? 'bg-slate-500/15 text-slate-400'
                      : 'bg-blue-500/15 text-blue-400'
                  }`}>
                    {listing.status === 'active' ? 'Aktif' : listing.status === 'passive' ? 'Pasif' : 'Satıldı'}
                  </span>
                </div>
              </div>

              <div className="flex shrink-0 gap-1">
                <button
                  onClick={() => setEditingListing(listing)}
                  className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-orange-400"
                  title="Düzenle"
                >
                  <Edit2 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleToggleStatus(listing)}
                  className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-amber-400"
                  title={listing.status === 'active' ? 'Pasife Al' : 'Aktifleştir'}
                >
                  {listing.status === 'active' ? <PowerOff className="h-4 w-4" /> : <Power className="h-4 w-4" />}
                </button>
                <button
                  onClick={() => handleDeleteListing(listing.id)}
                  className="rounded-lg p-2 text-slate-400 transition hover:bg-red-500/10 hover:text-red-400"
                  title="Sil"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit listing modal */}
      {editingListing && (
        <EditListingModal
          listing={editingListing}
          onChange={setEditingListing}
          onClose={() => setEditingListing(null)}
          onSave={handleUpdateListing}
        />
      )}
    </div>
  );
}

function ProfileField({
  label,
  value,
  onChange,
  icon,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  icon?: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-semibold text-slate-400">{label}</label>
      <div className="relative">
        {icon && <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">{icon}</span>}
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className={`w-full rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-orange-500/60 ${
            icon ? 'pl-9' : ''
          }`}
        />
      </div>
    </div>
  );
}

function EditListingModal({
  listing,
  onChange,
  onClose,
  onSave,
}: {
  listing: Listing;
  onChange: (l: Listing) => void;
  onClose: () => void;
  onSave: () => void;
}) {
  const CATEGORIES_LIST: Category[] = ['Regular', 'Silver', 'Premium', 'Chase', 'STH', 'TH'];
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-fade-in">
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl glass border border-slate-700/50 p-6 shadow-2xl animate-scale-in">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">İlanı Düzenle</h2>
          <button onClick={onClose} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-slate-400">Başlık</label>
            <input
              type="text"
              value={listing.title}
              onChange={(e) => onChange({ ...listing, title: e.target.value })}
              className="w-full rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-orange-500/60"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-slate-400">Açıklama</label>
            <textarea
              value={listing.description || ''}
              onChange={(e) => onChange({ ...listing, description: e.target.value })}
              rows={3}
              className="w-full resize-none rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-orange-500/60"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-slate-400">Kategori</label>
              <select
                value={listing.category}
                onChange={(e) => onChange({ ...listing, category: e.target.value as Category })}
                className="w-full rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-orange-500/60"
              >
                {CATEGORIES_LIST.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-slate-400">Fiyat (TL)</label>
              <input
                type="number"
                value={listing.price ?? ''}
                onChange={(e) => onChange({ ...listing, price: e.target.value ? parseFloat(e.target.value) : null })}
                disabled={listing.is_trade}
                className="w-full rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-orange-500/60 disabled:opacity-40"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-slate-400">Şehir</label>
              <select
                value={listing.city || ''}
                onChange={(e) => onChange({ ...listing, city: e.target.value || null })}
                className="w-full rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-orange-500/60"
              >
                <option value="">Şehir seçin</option>
                {TURKISH_CITIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-semibold text-slate-400">İlçe</label>
              <input
                type="text"
                value={listing.district || ''}
                onChange={(e) => onChange({ ...listing, district: e.target.value || null })}
                className="w-full rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-orange-500/60"
              />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm text-slate-300">
            <input
              type="checkbox"
              checked={listing.is_trade}
              onChange={(e) => onChange({ ...listing, is_trade: e.target.checked })}
              className="h-4 w-4 rounded border-slate-600 bg-slate-800 text-orange-500 focus:ring-orange-500/20"
            />
            Takaslı
          </label>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-slate-400">Kutu & Kondisyon</label>
            <select
              value={listing.condition || ''}
              onChange={(e) => onChange({ ...listing, condition: (e.target.value || null) as Condition | null })}
              className="w-full rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-orange-500/60"
            >
              <option value="">Seçin</option>
              {CONDITIONS.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="mt-5 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 rounded-xl border border-slate-700/50 py-2.5 text-sm font-bold text-slate-300 transition hover:bg-slate-700/40"
          >
            İptal
          </button>
          <button
            onClick={onSave}
            className="flex-1 rounded-xl bg-gradient-flame py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110"
          >
            Kaydet
          </button>
        </div>
      </div>
    </div>
  );
}

import { useEffect, useState, useCallback } from 'react';
import { Sparkles, Loader2, Search as SearchIcon, ArrowRight, Plus, PackageOpen } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useChat } from '@/context/ChatContext';
import type { ListingWithProfile } from '@/types';
import { ListingCard } from '@/components/ListingCard';
import { TrustBadge } from '@/components/TrustBadge';
import { CATEGORIES, CATEGORY_STYLES } from '@/constants';
import type { Category } from '@/types';

interface Props {
  onOpenListing: (id: string) => void;
  onNavigateSearch: () => void;
  onAddListing: () => void;
}

const PAGE_SIZE = 12;

export function HomePage({ onOpenListing, onNavigateSearch, onAddListing }: Props) {
  const [featured, setFeatured] = useState<ListingWithProfile[]>([]);
  const [feed, setFeed] = useState<ListingWithProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(0);
  const { blockedIds } = useChat();

  const fetchFeatured = useCallback(async () => {
    const { data } = await supabase
      .from('listings')
      .select('*, profiles!listings_profiles_id_fkey(*)')
      .eq('featured', true)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(8);
    setFeatured(((data as ListingWithProfile[]) || []).filter(
      (l) => !blockedIds.has(l.user_id)
    ));
  }, []);

  const fetchFeed = useCallback(async (pageNum: number) => {
    const { data } = await supabase
      .from('listings')
      .select('*, profiles!listings_profiles_id_fkey(*)')
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .range(pageNum * PAGE_SIZE, pageNum * PAGE_SIZE + PAGE_SIZE - 1);
    const rows = ((data as ListingWithProfile[]) || []).filter(
      (l) => !blockedIds.has(l.user_id)
    );
    if (pageNum === 0) {
      setFeed(rows);
    } else {
      setFeed((prev) => [...prev, ...rows]);
    }
    setHasMore(rows.length === PAGE_SIZE);
  }, []);

  useEffect(() => {
    setLoading(true);
    Promise.all([fetchFeatured(), fetchFeed(0)]).finally(() => setLoading(false));
  }, [fetchFeatured, fetchFeed]);

  const loadMore = async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    const next = page + 1;
    await fetchFeed(next);
    setPage(next);
    setLoadingMore(false);
  };

  return (
    <div className="animate-fade-in">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-800">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#131c31] to-[#0f172a]" />
        <div className="absolute -left-20 top-0 h-72 w-72 rounded-full bg-orange-600/20 blur-3xl" />
        <div className="absolute -right-20 bottom-0 h-72 w-72 rounded-full bg-red-600/15 blur-3xl" />
        <div className="relative mx-auto max-w-7xl px-4 py-14 text-center sm:px-6 sm:py-20">
          <div className="mb-4 flex justify-center">
            <TrustBadge />
          </div>
          <h1 className="text-3xl font-extrabold leading-tight text-white sm:text-5xl">
            Hot Wheels & Diecast
            <br />
            <span className="text-gradient-flame">İlan, Takas & Topluluk</span>
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-sm text-slate-400 sm:text-base">
            Türkiye'nin koleksiyonerlere özel platformunda nadir parçalarını keşfet,
            ilan ver, takas yap. Tüm ilanlar otomatik doğrulamadan geçer.
          </p>
          <button
            onClick={onNavigateSearch}
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-gradient-flame px-6 py-3 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 active:scale-95"
          >
            <SearchIcon className="h-4 w-4" />
            İlanları Keşfet
            <ArrowRight className="h-4 w-4" />
          </button>

          <div className="mt-8 flex flex-wrap justify-center gap-2">
            {CATEGORIES.map((cat) => (
              <span
                key={cat}
                className={`rounded-full border px-3 py-1 text-xs font-semibold ${CATEGORY_STYLES[cat as Category].badgeClass}`}
              >
                {CATEGORY_STYLES[cat as Category].label}
              </span>
            ))}
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
          </div>
        ) : (
          <>
            {featured.length > 0 && (
              <section className="mb-10">
                <div className="mb-5 flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-amber-400" />
                  <h2 className="text-xl font-bold text-white">Sponsorlu / Vitrin İlanları</h2>
                </div>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4">
                  {featured.map((l) => (
                    <ListingCard key={l.id} listing={l} onClick={() => onOpenListing(l.id)} />
                  ))}
                </div>
              </section>
            )}

            <section>
              <div className="mb-5 flex items-center justify-between">
                <h2 className="text-xl font-bold text-white">Günün / Yeni İlanlar</h2>
                {feed.length > 0 && (
                  <button
                    onClick={onNavigateSearch}
                    className="text-sm font-semibold text-orange-400 transition hover:text-orange-300"
                  >
                    Tümünü Gör →
                  </button>
                )}
              </div>

              {feed.length === 0 && featured.length === 0 ? (
                <EmptyState onAddListing={onAddListing} />
              ) : (
                <>
                  {feed.length > 0 && (
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4">
                      {feed.map((l) => (
                        <ListingCard key={l.id} listing={l} onClick={() => onOpenListing(l.id)} />
                      ))}
                    </div>
                  )}
                  {hasMore && (
                    <div className="mt-8 flex justify-center">
                      <button
                        onClick={loadMore}
                        disabled={loadingMore}
                        className="inline-flex items-center gap-2 rounded-xl border border-slate-700/50 glass px-6 py-2.5 text-sm font-semibold text-slate-200 transition hover:bg-slate-700/40 disabled:opacity-50"
                      >
                        {loadingMore ? (
                          <>
                            <Loader2 className="h-4 w-4 animate-spin" />
                            Yükleniyor...
                          </>
                        ) : (
                          'Daha Fazla Yükle'
                        )}
                      </button>
                    </div>
                  )}
                </>
              )}
            </section>
          </>
        )}
      </div>
    </div>
  );
}

function EmptyState({ onAddListing }: { onAddListing: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl glass-card py-16 text-center animate-slide-up">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-orange-500/10 border border-orange-500/20">
        <PackageOpen className="h-8 w-8 text-orange-500" />
      </div>
      <h3 className="text-lg font-bold text-white">Henüz ilan bulunmuyor</h3>
      <p className="mt-1.5 max-w-sm text-sm text-slate-400">
        İlk ilanı sen ver! Hot Wheels ve diecast koleksiyonundan parçalarını paylaş.
      </p>
      <button
        onClick={onAddListing}
        className="mt-5 inline-flex items-center gap-2 rounded-xl bg-gradient-flame px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 active:scale-95"
      >
        <Plus className="h-4 w-4" />
        İlan Ver
      </button>
    </div>
  );
}

import { useState, useEffect, useCallback } from 'react';
import {
  Shield,
  Flag,
  Trash2,
  Check,
  X,
  Loader2,
  Ban,
  ExternalLink,
  ArrowLeft,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { formatRelativeDate } from '@/constants';
import type { Report, Profile, Listing } from '@/types';

interface ReportRow extends Report {
  reporter_profile: Pick<Profile, 'display_name'> | null;
  reported_profile: Pick<Profile, 'display_name'> | null;
  listing: Pick<Listing, 'id' | 'title'> | null;
}

interface Props {
  onBack: () => void;
  onOpenListing: (id: string) => void;
}

export function AdminPage({ onBack, onOpenListing }: Props) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [reports, setReports] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [filter, setFilter] = useState<'pending' | 'resolved' | 'dismissed' | 'all'>('pending');

  const fetchReports = useCallback(async () => {
    setLoading(true);
    let query = supabase
      .from('reports')
      .select(
        '*, reporter_profile:profiles!reports_reporter_id_fkey(display_name), reported_profile:profiles!reports_reported_user_id_fkey(display_name), listing:listings(id, title)'
      )
      .order('created_at', { ascending: false });
    if (filter !== 'all') query = query.eq('status', filter);
    const { data } = await query;
    setReports((data as ReportRow[]) || []);
    setLoading(false);
  }, [filter]);

  useEffect(() => {
    fetchReports();
  }, [fetchReports]);

  const handleDismiss = async (id: string) => {
    setActionLoading(id);
    await supabase.from('reports').update({ status: 'dismissed' }).eq('id', id);
    setActionLoading(null);
    showToast('Şikayet reddedildi.', 'success');
    fetchReports();
  };

  const handleResolve = async (id: string) => {
    setActionLoading(id);
    await supabase.from('reports').update({ status: 'resolved' }).eq('id', id);
    setActionLoading(null);
    showToast('Şikayet çözüldü olarak işaretlendi.', 'success');
    fetchReports();
  };

  const handleDeleteListing = async (report: ReportRow) => {
    if (!report.listing_id) return;
    if (!confirm('Bu ilanı silmek istediğinize emin misiniz?')) return;
    setActionLoading(report.id);
    await supabase.from('listings').delete().eq('id', report.listing_id);
    await supabase.from('reports').update({ status: 'resolved' }).eq('id', report.id);
    setActionLoading(null);
    showToast('İlan silindi ve şikayet çözüldü.', 'success');
    fetchReports();
  };

  const handleBanUser = async (report: ReportRow) => {
    if (!confirm('Bu kullanıcıyı banlamak istediğinize emin misiniz?')) return;
    setActionLoading(report.id);
    await supabase.from('listings').delete().eq('user_id', report.reported_user_id);
    await supabase.from('reports').update({ status: 'resolved' }).eq('id', report.id);
    setActionLoading(null);
    showToast('Kullanıcının tüm ilanları silindi ve şikayet çözüldü.', 'success');
    fetchReports();
  };

  const pendingCount = reports.filter((r) => r.status === 'pending').length;

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 animate-fade-in sm:px-6">
      <div className="mb-6 flex items-center gap-3">
        <button
          onClick={onBack}
          className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-white"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <Shield className="h-6 w-6 text-orange-500" />
        <h1 className="text-2xl font-extrabold text-white">Admin Paneli</h1>
        {pendingCount > 0 && (
          <span className="rounded-full bg-red-500/20 px-2.5 py-0.5 text-xs font-bold text-red-400">
            {pendingCount} bekleyen
          </span>
        )}
      </div>

      <div className="mb-4 flex gap-2">
        {(['pending', 'resolved', 'dismissed', 'all'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${
              filter === f
                ? 'bg-gradient-flame text-white'
                : 'glass text-slate-400 hover:text-slate-200'
            }`}
          >
            {f === 'pending' ? 'Bekleyen' : f === 'resolved' ? 'Çözüldü' : f === 'dismissed' ? 'Reddedildi' : 'Tümü'}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-orange-500" />
        </div>
      ) : reports.length === 0 ? (
        <div className="flex flex-col items-center justify-center rounded-2xl glass-card py-16 text-center">
          <Flag className="mb-3 h-10 w-10 text-slate-600" />
          <p className="font-semibold text-slate-300">Bu filtrede şikayet yok</p>
        </div>
      ) : (
        <div className="space-y-3">
          {reports.map((report) => (
            <div
              key={report.id}
              className="rounded-xl glass-card p-4"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="mb-1.5 flex items-center gap-2">
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                      report.status === 'pending'
                        ? 'bg-red-500/15 text-red-400'
                        : report.status === 'resolved'
                        ? 'bg-green-500/15 text-green-400'
                        : 'bg-slate-500/15 text-slate-400'
                    }`}>
                      {report.status === 'pending' ? 'Bekliyor' : report.status === 'resolved' ? 'Çözüldü' : 'Reddedildi'}
                    </span>
                    <span className="rounded-full bg-orange-500/15 px-2 py-0.5 text-[10px] font-bold text-orange-400">
                      {report.reason}
                    </span>
                    <span className="text-[10px] text-slate-500">
                      {formatRelativeDate(report.created_at)}
                    </span>
                  </div>

                  <div className="space-y-0.5 text-sm">
                    <p className="text-slate-300">
                      <span className="text-slate-500">Şikayet eden:</span>{' '}
                      <span className="font-semibold text-white">
                        {report.reporter_profile?.display_name || 'Bilinmiyor'}
                      </span>
                    </p>
                    <p className="text-slate-300">
                      <span className="text-slate-500">Şikayet edilen:</span>{' '}
                      <span className="font-semibold text-white">
                        {report.reported_profile?.display_name || 'Bilinmiyor'}
                      </span>
                    </p>
                    {report.listing && (
                      <button
                        onClick={() => onOpenListing(report.listing!.id)}
                        className="inline-flex items-center gap-1 text-orange-400 transition hover:text-orange-300"
                      >
                        <ExternalLink className="h-3 w-3" />
                        {report.listing.title}
                      </button>
                    )}
                    {report.description && (
                      <p className="mt-2 rounded-lg bg-slate-900/40 px-3 py-2 text-xs text-slate-400">
                        {report.description}
                      </p>
                    )}
                  </div>
                </div>

                {report.status === 'pending' && (
                  <div className="flex shrink-0 gap-1.5">
                    <button
                      onClick={() => handleResolve(report.id)}
                      disabled={actionLoading === report.id}
                      className="rounded-lg bg-green-500/15 p-2 text-green-400 transition hover:bg-green-500/25 disabled:opacity-50"
                      title="Çözüldü"
                    >
                      {actionLoading === report.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Check className="h-4 w-4" />
                      )}
                    </button>
                    <button
                      onClick={() => handleDismiss(report.id)}
                      disabled={actionLoading === report.id}
                      className="rounded-lg bg-slate-500/15 p-2 text-slate-400 transition hover:bg-slate-500/25 disabled:opacity-50"
                      title="Reddet"
                    >
                      <X className="h-4 w-4" />
                    </button>
                    {report.listing_id && (
                      <button
                        onClick={() => handleDeleteListing(report)}
                        disabled={actionLoading === report.id}
                        className="rounded-lg bg-red-500/15 p-2 text-red-400 transition hover:bg-red-500/25 disabled:opacity-50"
                        title="İlanı Sil"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                    <button
                      onClick={() => handleBanUser(report)}
                      disabled={actionLoading === report.id}
                      className="rounded-lg bg-red-500/15 p-2 text-red-400 transition hover:bg-red-500/25 disabled:opacity-50"
                      title="Kullanıcıyı Banla"
                    >
                      <Ban className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

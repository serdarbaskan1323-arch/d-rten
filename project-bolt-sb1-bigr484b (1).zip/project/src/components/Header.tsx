interface Props {
  current: 'home' | 'search' | 'listing' | 'profile' | 'admin';
  onNavigate: (page: 'home' | 'search' | 'listing' | 'profile' | 'admin') => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenFilter: () => void;
  onAddListing: () => void;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onToggleDrawer: () => void;
  onOpenChat: () => void;
}

import { Search, SlidersHorizontal, Plus, User, Menu, MessageSquare, Shield } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useChat } from '@/context/ChatContext';
import { TrustBadge } from '@/components/TrustBadge';
import { HWLogo } from '@/components/HWLogo';

export function Header({
  current,
  onNavigate,
  searchQuery,
  onSearchChange,
  onOpenFilter,
  onAddListing,
  onOpenAuth,
  onOpenProfile,
  onToggleDrawer,
  onOpenChat,
}: Props) {
  const { user, profile } = useAuth();
  const { unreadTotal } = useChat();

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNavigate('search');
  };

  return (
    <header className="sticky top-0 z-40 glass border-b border-slate-700/40">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        <button
          onClick={onToggleDrawer}
          className="rounded-lg p-2 text-slate-300 transition hover:bg-slate-700/40 hover:text-white lg:hidden"
          aria-label="Menü"
        >
          <Menu className="h-5 w-5" />
        </button>

        <button
          onClick={() => onNavigate('home')}
          className="flex shrink-0 items-center gap-2"
        >
          <HWLogo size={36} className="shrink-0" />
          <span className="hidden text-lg font-extrabold tracking-tight text-white sm:block">
            Garaj<span className="text-gradient-flame">64</span>
          </span>
        </button>

        <form
          onSubmit={handleSearchSubmit}
          className="relative flex flex-1 items-center"
        >
          <Search className="pointer-events-none absolute left-3 h-4 w-4 text-slate-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Model veya ilan ara..."
            className="w-full rounded-xl border border-slate-700/50 bg-slate-900/60 py-2 pl-10 pr-24 text-sm text-slate-100 placeholder-slate-500 outline-none transition focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
          />
          <button
            type="button"
            onClick={onOpenFilter}
            className="absolute right-1.5 inline-flex items-center gap-1.5 rounded-lg bg-slate-700/60 px-3 py-1.5 text-xs font-semibold text-slate-200 transition hover:bg-slate-600/70"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            Filtrele
          </button>
        </form>

        <button
          onClick={onAddListing}
          className="hidden shrink-0 items-center gap-1.5 rounded-xl bg-gradient-flame px-4 py-2 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 active:scale-95 sm:inline-flex"
        >
          <Plus className="h-4 w-4" />
          İlan Ver
        </button>

        {user && (
          <button
            onClick={onOpenChat}
            className="relative shrink-0 rounded-xl glass p-2 text-slate-300 transition hover:bg-slate-700/40 hover:text-white"
            title="Mesajlar"
          >
            <MessageSquare className="h-5 w-5" />
            {unreadTotal > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-orange-500 px-1 text-[10px] font-bold text-white">
                {unreadTotal > 99 ? '99+' : unreadTotal}
              </span>
            )}
          </button>
        )}

        {user && profile?.role === 'admin' && (
          <button
            onClick={() => onNavigate('admin')}
            className={`shrink-0 rounded-xl p-2 transition ${
              current === 'admin'
                ? 'bg-orange-500/20 text-orange-400'
                : 'glass text-slate-300 hover:bg-slate-700/40 hover:text-white'
            }`}
            title="Admin Paneli"
          >
            <Shield className="h-5 w-5" />
          </button>
        )}

        {user ? (
          <button
            onClick={onOpenProfile}
            className="flex shrink-0 items-center gap-2 rounded-xl glass px-2 py-1.5 transition hover:bg-slate-700/40"
            title="Hesabım"
          >
            {profile?.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt=""
                className="h-7 w-7 rounded-full object-cover"
              />
            ) : (
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-flame text-xs font-bold text-white">
                {(profile?.display_name || user.email || '?').charAt(0).toUpperCase()}
              </span>
            )}
            <span className="hidden max-w-[80px] truncate text-sm font-medium text-slate-200 md:block">
              {profile?.display_name || 'Hesabım'}
            </span>
          </button>
        ) : (
          <button
            onClick={onOpenAuth}
            className="flex shrink-0 items-center gap-1.5 rounded-xl glass px-3 py-2 text-sm font-semibold text-slate-200 transition hover:bg-slate-700/40"
          >
            <User className="h-4 w-4" />
            <span className="hidden sm:block">Giriş</span>
          </button>
        )}
      </div>

      {current === 'home' && (
        <div className="hidden justify-center px-6 pb-2 lg:flex">
          <TrustBadge />
        </div>
      )}
    </header>
  );
}

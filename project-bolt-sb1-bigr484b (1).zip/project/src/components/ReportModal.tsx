import { useState } from 'react';
import { X, Flag, Loader2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { sanitizeText } from '@/lib/sanitize';
import { containsProfanity } from '@/lib/profanity';

interface Props {
  open: boolean;
  onClose: () => void;
  reportedUserId: string;
  reportedUserName: string;
  listingId?: string | null;
  listingTitle?: string | null;
}

const REPORT_REASONS = [
  'Sahte İlan',
  'Uygunsuz İçerik / Küfür',
  'Dolandırıcılık Şüphesi',
  'Spam / Reklam',
  'Yanlış Kategori',
  'Diğer',
];

export function ReportModal({
  open,
  onClose,
  reportedUserId,
  reportedUserName,
  listingId,
  listingTitle,
}: Props) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [reason, setReason] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!user) {
      setError('Şikayet etmek için giriş yapmalısınız.');
      return;
    }
    if (!reason) {
      setError('Lütfen bir şikayet sebebi seçin.');
      return;
    }
    if (containsProfanity(description)) {
      setError('Açıklamanızda uygunsuz içerik tespit edildi.');
      return;
    }
    setSubmitting(true);
    const { error: insertError } = await supabase.from('reports').insert({
      reporter_id: user.id,
      reported_user_id: reportedUserId,
      listing_id: listingId || null,
      reason,
      description: sanitizeText(description) || null,
    });
    setSubmitting(false);
    if (insertError) {
      setError('Şikayet gönderilemedi. Lütfen tekrar deneyin.');
      return;
    }
    showToast('Şikayetiniz alındı. Ekibimiz inceleyecek.', 'success');
    setReason('');
    setDescription('');
    onClose();
  };

  const handleClose = () => {
    setReason('');
    setDescription('');
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm animate-fade-in sm:items-center sm:p-4">
      <div className="w-full max-w-md rounded-t-2xl glass border border-slate-700/50 shadow-2xl animate-slide-up sm:rounded-2xl">
        <div className="flex items-center justify-between border-b border-slate-700/40 px-5 py-4">
          <h2 className="flex items-center gap-2 text-lg font-bold text-white">
            <Flag className="h-5 w-5 text-red-500" />
            Şikayet Et
          </h2>
          <button
            onClick={handleClose}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 px-5 py-5">
          <div className="rounded-xl border border-slate-700/50 bg-slate-900/40 px-3 py-2.5 text-sm text-slate-300">
            <span className="font-semibold text-slate-200">Şikayet edilen:</span>{' '}
            {reportedUserName}
            {listingTitle && (
              <span className="block text-xs text-slate-500">İlan: {listingTitle}</span>
            )}
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-300">
              Şikayet Sebebi *
            </label>
            <div className="grid grid-cols-2 gap-2">
              {REPORT_REASONS.map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setReason(r)}
                  className={`rounded-lg border px-3 py-2 text-xs font-semibold transition ${
                    reason === r
                      ? 'border-red-500/60 bg-red-500/15 text-red-300'
                      : 'border-slate-700/50 bg-slate-900/40 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-300">
              Açıklama
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              maxLength={500}
              placeholder="Durumu kısaca açıklayın..."
              className="w-full resize-none rounded-xl border border-slate-700/50 bg-slate-900/60 px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-red-500/60 focus:ring-2 focus:ring-red-500/20"
            />
            <p className="mt-1 text-[10px] text-slate-500">
              Sadece metin. Görsel eklenemez.
            </p>
          </div>

          {error && (
            <div className="flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-400">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          <div className="flex gap-3 border-t border-slate-700/40 pt-4">
            <button
              type="button"
              onClick={handleClose}
              className="flex-1 rounded-xl border border-slate-700/50 py-2.5 text-sm font-bold text-slate-300 transition hover:bg-slate-700/40"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={submitting || !reason}
              className="flex-1 rounded-xl bg-red-500 py-2.5 text-sm font-bold text-white shadow-lg shadow-red-900/30 transition hover:brightness-110 disabled:opacity-50 active:scale-[0.98]"
            >
              {submitting ? (
                <span className="inline-flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Gönderiliyor...
                </span>
              ) : (
                'Şikayet Gönder'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

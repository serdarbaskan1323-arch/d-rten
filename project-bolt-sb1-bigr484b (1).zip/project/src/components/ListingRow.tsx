import { MapPin, Eye, ChevronRight, RefreshCw } from 'lucide-react';
import type { ListingWithProfile } from '@/types';
import { CategoryBadge } from '@/components/CategoryBadge';
import { ConditionBadge } from '@/components/ConditionBadge';
import { formatPrice, formatRelativeDate, formatLocation, buildGoogleMapsUrl } from '@/constants';

interface Props {
  listing: ListingWithProfile;
  onClick: () => void;
}

export function ListingRow({ listing, onClick }: Props) {
  const primaryImage = listing.images[0];

  return (
    <button
      onClick={onClick}
      className="group flex w-full items-center gap-4 rounded-xl glass-card p-3 text-left transition hover:border-orange-500/30 hover:bg-slate-800/40"
    >
      <div className="relative h-20 w-28 shrink-0 overflow-hidden rounded-lg bg-slate-900 sm:h-24 sm:w-32">
        {primaryImage ? (
          <img
            src={primaryImage}
            alt={listing.title}
            loading="lazy"
            className="h-full w-full object-contain p-1.5 transition duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-slate-600">
            <span className="text-2xl">🏎️</span>
          </div>
        )}
        <div className="absolute left-1 top-1">
          <CategoryBadge category={listing.category} />
        </div>
      </div>

      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <h3 className="truncate text-sm font-bold text-slate-100 transition group-hover:text-orange-400 sm:text-base">
          {listing.title}
        </h3>
        <div className="flex items-center gap-1 text-xs text-slate-400">
          <MapPin className="h-3 w-3 shrink-0" />
          {(() => {
            const mapsUrl = buildGoogleMapsUrl(listing.city, listing.district);
            if (mapsUrl) {
              return (
                <a
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="truncate transition hover:text-orange-400"
                  onClick={(e) => e.stopPropagation()}
                >
                  {formatLocation(listing.city, listing.district)}
                </a>
              );
            }
            return <span className="truncate">{formatLocation(listing.city, listing.district)}</span>;
          })()}
        </div>
        <div className="flex items-center gap-3">
          {listing.is_trade ? (
            <span className="inline-flex items-center gap-1 rounded-md bg-blue-500/15 px-2 py-0.5 text-xs font-bold text-blue-400">
              <RefreshCw className="h-3 w-3" />
              Takas
            </span>
          ) : (
            <span className="text-sm font-extrabold text-orange-400 sm:text-base">
              {formatPrice(listing.price)}
            </span>
          )}
          {listing.condition && <ConditionBadge condition={listing.condition} />}
          <span className="text-[10px] text-slate-500">{formatRelativeDate(listing.created_at)}</span>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-slate-500">
          <Eye className="h-3 w-3" />
          {listing.views} görüntülenme
        </div>
      </div>

      <ChevronRight className="h-5 w-5 shrink-0 text-slate-600 transition group-hover:translate-x-0.5 group-hover:text-orange-400" />
    </button>
  );
}

import { X, Home, Search, Plus, User, LogOut, MessageSquare, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { HWLogo } from '@/components/HWLogo';

interface Props {
  open: boolean;
  onClose: () => void;
  onNavigate: (page: 'home' | 'search' | 'listing' | 'profile') => void;
  onAddListing: () => void;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
}

export function Drawer({ open, onClose, onNavigate, onAddListing, onOpenAuth, onOpenProfile }: Props) {
  const { user, profile, signOut } = useAuth();

  const handleNav = (page: 'home' | 'search' | 'listing' | 'profile') => {
    onNavigate(page);
    onClose();
  };

  const handleAdd = () => {
    onAddListing();
    onClose();
  };

  const handleProfile = () => {
    onOpenProfile();
    onClose();
  };

  const handleSignOut = async () => {
    await signOut();
    onClose();
  };

  return (
    <>
      <div
        className={`fixed inset-0 z-50 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${
          open ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
        onClick={onClose}
      />
      <aside
        className={`fixed left-0 top-0 z-50 flex h-full w-72 flex-col glass border-r border-slate-700/40 transition-transform duration-300 ${
          open ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between border-b border-slate-700/40 px-5 py-4">
          <div className="flex items-center gap-2">
            <HWLogo size={32} className="shrink-0" />
            <span className="text-lg font-extrabold text-white">
              Garaj<span className="text-gradient-flame">64</span>
            </span>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {user ? (
          <button
            onClick={handleProfile}
            className="flex items-center gap-3 border-b border-slate-700/40 px-5 py-4 text-left transition hover:bg-slate-700/30"
          >
            {profile?.avatar_url ? (
              <img src={profile.avatar_url} alt="" className="h-11 w-11 rounded-full object-cover" />
            ) : (
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-flame text-base font-bold text-white">
                {(profile?.display_name || user.email || '?').charAt(0).toUpperCase()}
              </span>
            )}
            <div className="min-w-0">
              <p className="truncate text-sm font-bold text-white">
                {profile?.display_name || 'Kullanıcı'}
              </p>
              <p className="truncate text-xs text-slate-400">{user.email}</p>
            </div>
          </button>
        ) : (
          <div className="border-b border-slate-700/40 px-5 py-4">
            <button
              onClick={() => { onOpenAuth(); onClose(); }}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-flame px-4 py-2.5 text-sm font-bold text-white transition hover:brightness-110"
            >
              <User className="h-4 w-4" />
              Giriş Yap / Kayıt Ol
            </button>
          </div>
        )}

        <nav className="flex-1 space-y-1 px-3 py-4">
          <DrawerItem icon={<Home className="h-5 w-5" />} label="Anasayfa" onClick={() => handleNav('home')} />
          <DrawerItem icon={<Search className="h-5 w-5" />} label="İlan Ara" onClick={() => handleNav('search')} />
          <DrawerItem icon={<Plus className="h-5 w-5" />} label="İlan Ver" onClick={handleAdd} />
          {user && (
            <>
              <DrawerItem icon={<User className="h-5 w-5" />} label="Hesabım / Ben" onClick={handleProfile} />
              <DrawerItem icon={<MessageSquare className="h-5 w-5" />} label="İlanlarım" onClick={handleProfile} />
            </>
          )}
        </nav>

        <div className="space-y-3 border-t border-slate-700/40 px-5 py-4">
          <div className="flex items-center gap-2 rounded-lg bg-slate-800/40 px-3 py-2 text-xs text-slate-300">
            <ShieldCheck className="h-4 w-4 shrink-0 text-orange-500" />
            Otomatik Korumalı & Doğrulanmış
          </div>
          {user && (
            <button
              onClick={handleSignOut}
              className="flex w-full items-center gap-2 rounded-lg border border-slate-700/50 px-3 py-2 text-sm font-medium text-slate-300 transition hover:border-red-500/40 hover:text-red-400"
            >
              <LogOut className="h-4 w-4" />
              Çıkış Yap
            </button>
          )}
        </div>
      </aside>
    </>
  );
}

function DrawerItem({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-slate-700/40 hover:text-white"
    >
      {icon}
      {label}
    </button>
  );
}

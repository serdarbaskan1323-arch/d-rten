import { useState } from 'react';
import { MessageSquare, Send, Heart } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { moderateText } from '@/lib/moderation';
import { sanitizeText } from '@/lib/sanitize';
import { useAuth } from '@/context/AuthContext';
import { HWLogo } from '@/components/HWLogo';

interface Props {
  onNavigateHome: () => void;
}

export function Footer({ onNavigateHome }: Props) {
  const [feedback, setFeedback] = useState('');
  const [name, setName] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'ok' | 'error' | 'flagged'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const { user, profile } = useAuth();
  const limit = 300;
  const remaining = limit - feedback.length;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedback.trim()) return;
    if (feedback.length > limit) return;
    setStatus('sending');
    setErrorMsg('');

    const mod = await moderateText(feedback);
    if (mod.flagged) {
      await supabase.from('feedback').insert({
        user_id: user?.id ?? null,
        display_name: sanitizeText(name) || profile?.display_name || null,
        message: sanitizeText(feedback),
        ai_flagged: true,
        ai_reason: mod.reason || mod.categories?.join(', '),
      });
      setStatus('flagged');
      setFeedback('');
      return;
    }

    const { error } = await supabase.from('feedback').insert({
      user_id: user?.id ?? null,
      display_name: sanitizeText(name) || profile?.display_name || null,
      message: sanitizeText(feedback),
      ai_flagged: false,
    });

    if (error) {
      setStatus('error');
      setErrorMsg('Geri bildirim gönderilemedi, lütfen tekrar deneyin.');
    } else {
      setStatus('ok');
      setFeedback('');
    }
  };

  return (
    <footer className="mt-16 border-t border-slate-800 bg-[#0c1424]/80">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <div className="mb-4 flex items-center gap-2">
              <HWLogo size={32} className="shrink-0" />
              <span className="text-lg font-extrabold text-white">
                Garaj<span className="text-gradient-flame">64</span>
              </span>
            </div>
            <p className="max-w-xs text-sm leading-relaxed text-slate-400">
              Türkiye'nin Hot Wheels ve diecast koleksiyonerleri için ilan,
              takas ve topluluk platformu. Tüm ilanlar yapay zeka ile doğrulanır.
            </p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs text-slate-300">
              <span className="h-2 w-2 rounded-full bg-green-400 animate-pulse" />
              Otomatik Korumalı & Doğrulanmış İlan Platformu
            </div>
          </div>

          <div>
            <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-slate-300">
              Hızlı Erişim
            </h3>
            <ul className="space-y-2.5 text-sm text-slate-400">
              <li>
                <button onClick={onNavigateHome} className="transition hover:text-orange-400">
                  Anasayfa
                </button>
              </li>
              <li>
                <button onClick={onNavigateHome} className="transition hover:text-orange-400">
                  Vitrin İlanları
                </button>
              </li>
              <li>
                <button onClick={onNavigateHome} className="transition hover:text-orange-400">
                  Günün İlanları
                </button>
              </li>
              <li>
                <span className="text-slate-600">Gizlilik Politikası</span>
              </li>
              <li>
                <span className="text-slate-600">Kullanım Şartları</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-300">
              <MessageSquare className="h-4 w-4 text-orange-500" />
              Fikirleriniz Bizim İçin Değerli
            </h3>
            <p className="mb-3 text-xs text-slate-400">
              Sitemiz yeni açıldı, yorumlarınız ve fikirleriniz bizim için değerlidir.
            </p>
            <form onSubmit={handleSubmit} className="space-y-3">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Adınız (opsiyonel)"
                maxLength={50}
                className="w-full rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/50"
              />
              <div className="relative">
                <textarea
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value.slice(0, limit))}
                  placeholder="Görüş ve önerilerinizi yazın..."
                  rows={3}
                  maxLength={limit}
                  className="w-full resize-none rounded-lg border border-slate-700/50 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/50"
                />
                <span
                  className={`absolute bottom-2 right-2 text-[10px] ${
                    remaining < 30 ? 'text-orange-400' : 'text-slate-500'
                  }`}
                >
                  {remaining}
                </span>
              </div>
              <button
                type="submit"
                disabled={status === 'sending' || !feedback.trim()}
                className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-gradient-flame px-4 py-2 text-sm font-bold text-white transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Send className="h-4 w-4" />
                {status === 'sending' ? 'Gönderiliyor...' : 'Gönder'}
              </button>
              {status === 'ok' && (
                <p className="text-xs font-medium text-green-400 animate-fade-in">
                  Teşekkürler! Geri bildiriminiz alındı.
                </p>
              )}
              {status === 'flagged' && (
                <p className="text-xs font-medium text-red-400 animate-fade-in">
                  Mesajınız uygun olmayan içerik tespit ettiği için filtrelenmiştir.
                </p>
              )}
              {status === 'error' && (
                <p className="text-xs font-medium text-red-400">{errorMsg}</p>
              )}
            </form>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-slate-800 pt-6 text-xs text-slate-500 sm:flex-row">
          <p>© 2026 Garaj64 — Tüm hakları saklıdır.</p>
          <p className="flex items-center gap-1">
            Türkiye'de koleksiyonerler için <Heart className="h-3 w-3 text-orange-500" /> ile yapıldı
          </p>
        </div>
      </div>
    </footer>
  );
}

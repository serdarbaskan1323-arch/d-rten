import { useState } from 'react';
import { X, Mail, Lock, User, ShieldCheck } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { containsProfanity } from '@/lib/profanity';
import { HWLogo } from '@/components/HWLogo';

interface Props {
  open: boolean;
  onClose: () => void;
}

export function AuthModal({ open, onClose }: Props) {
  const { signIn, signUp } = useAuth();
  const { showToast } = useToast();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!open) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    if (mode === 'signup') {
      if (!displayName.trim()) {
        setError('Lütfen görünen adınızı girin.');
        setLoading(false);
        return;
      }
      if (containsProfanity(displayName)) {
        setError('Görünen adınızda uygunsuz içerik tespit edildi.');
        setLoading(false);
        return;
      }
      if (password.length < 6) {
        setError('Şifre en az 6 karakter olmalıdır.');
        setLoading(false);
        return;
      }
      const { error: err } = await signUp(email, password, displayName.trim());
      if (err) {
        setError(err);
      } else {
        showToast('Kayıt başarılı! Hoş geldiniz.', 'success');
        handleClose();
      }
    } else {
      const { error: err } = await signIn(email, password);
      if (err) {
        setError(err);
      } else {
        showToast('Başarıyla giriş yapıldı!', 'success');
        handleClose();
      }
    }
    setLoading(false);
  };

  const handleClose = () => {
    setEmail('');
    setPassword('');
    setDisplayName('');
    setError(null);
    setMode('signin');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md rounded-2xl glass border border-slate-700/50 p-6 shadow-2xl animate-scale-in">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HWLogo size={36} className="shrink-0" />
            <span className="text-lg font-extrabold text-white">
              Garaj<span className="text-gradient-flame">64</span>
            </span>
          </div>
          <button onClick={handleClose} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mb-5 flex rounded-xl bg-slate-900/60 p-1">
          <button
            onClick={() => { setMode('signin'); setError(null); }}
            className={`flex-1 rounded-lg py-2 text-sm font-semibold transition ${
              mode === 'signin' ? 'bg-gradient-flame text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Giriş Yap
          </button>
          <button
            onClick={() => { setMode('signup'); setError(null); }}
            className={`flex-1 rounded-lg py-2 text-sm font-semibold transition ${
              mode === 'signup' ? 'bg-gradient-flame text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Kayıt Ol
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <Field
              icon={<User className="h-4 w-4" />}
              type="text"
              placeholder="Görünen Ad"
              value={displayName}
              onChange={setDisplayName}
            />
          )}
          <Field
            icon={<Mail className="h-4 w-4" />}
            type="email"
            placeholder="E-posta"
            value={email}
            onChange={setEmail}
          />
          <Field
            icon={<Lock className="h-4 w-4" />}
            type="password"
            placeholder="Şifre"
            value={password}
            onChange={setPassword}
          />

          {error && (
            <p className="rounded-lg bg-red-500/10 border border-red-500/30 px-3 py-2 text-sm text-red-400">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-gradient-flame py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 disabled:opacity-60 active:scale-[0.98]"
          >
            {loading ? 'İşleniyor...' : mode === 'signin' ? 'Giriş Yap' : 'Hesap Oluştur'}
          </button>
        </form>

        <div className="mt-5 flex items-center justify-center gap-1.5 text-xs text-slate-500">
          <ShieldCheck className="h-3.5 w-3.5 text-orange-500" />
          Güvenli e-posta / şifre girişi
        </div>
      </div>
    </div>
  );
}

function Field({
  icon,
  type,
  placeholder,
  value,
  onChange,
}: {
  icon: React.ReactNode;
  type: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="relative">
      <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
        {icon}
      </span>
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required
        className="w-full rounded-xl border border-slate-700/50 bg-slate-900/60 py-2.5 pl-10 pr-3 text-sm text-slate-100 placeholder-slate-500 outline-none transition focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
      />
    </div>
  );
}

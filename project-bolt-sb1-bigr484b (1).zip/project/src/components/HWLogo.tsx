interface Props {
  size?: number;
  className?: string;
}

export function HWLogo({ size = 36, className = '' }: Props) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="gr64-silver" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f8fafc" />
          <stop offset="40%" stopColor="#cbd5e1" />
          <stop offset="70%" stopColor="#94a3b8" />
          <stop offset="100%" stopColor="#64748b" />
        </linearGradient>
        <linearGradient id="gr64-orange" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0%" stopColor="#e60000" />
          <stop offset="50%" stopColor="#ff5500" />
          <stop offset="100%" stopColor="#ff8c1a" />
        </linearGradient>
        <linearGradient id="gr64-door" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1e293b" />
          <stop offset="100%" stopColor="#0f172a" />
        </linearGradient>
        <filter id="gr64-glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="0.8" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Silver hexagonal emblem background */}
      <path
        d="M24 2 L42 11 L42 37 L24 46 L6 37 L6 11 Z"
        fill="url(#gr64-silver)"
        stroke="#475569"
        strokeWidth="0.5"
      />

      {/* Dark inner hexagon */}
      <path
        d="M24 5 L39 12.5 L39 35.5 L24 43 L9 35.5 L9 12.5 Z"
        fill="#0f172a"
      />

      {/* Garage roof line */}
      <path
        d="M11 22 L24 14 L37 22"
        stroke="url(#gr64-orange)"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        filter="url(#gr64-glow)"
      />

      {/* Garage door panels */}
      <rect x="13" y="24" width="22" height="14" rx="1" fill="url(#gr64-door)" stroke="#334155" strokeWidth="0.5" />
      <line x1="13" y1="28" x2="35" y2="28" stroke="#475569" strokeWidth="0.6" />
      <line x1="13" y1="32" x2="35" y2="32" stroke="#475569" strokeWidth="0.6" />
      <line x1="13" y1="36" x2="35" y2="36" stroke="#475569" strokeWidth="0.6" />
      <line x1="24" y1="24" x2="24" y2="38" stroke="#475569" strokeWidth="0.6" />

      {/* Orange "64" number */}
      <text
        x="24"
        y="33"
        textAnchor="middle"
        fontSize="9"
        fontWeight="900"
        fontFamily="Arial, sans-serif"
        fill="url(#gr64-orange)"
        filter="url(#gr64-glow)"
      >
        64
      </text>
    </svg>
  );
}

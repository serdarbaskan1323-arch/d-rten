import { useState, useEffect } from 'react';
import { X, Search, Check, RotateCcw } from 'lucide-react';
import type { FilterState, Category, Condition } from '@/types';
import { CATEGORIES, CATEGORY_LABELS, TURKISH_CITIES, CATEGORY_STYLES, CONDITIONS, CONDITION_STYLES } from '@/constants';

interface Props {
  open: boolean;
  onClose: () => void;
  onApply: (filter: FilterState) => void;
  initial: FilterState;
}

export function FilterModal({ open, onClose, onApply, initial }: Props) {
  const [query, setQuery] = useState(initial.query);
  const [category, setCategory] = useState<FilterState['category']>(initial.category);
  const [city, setCity] = useState<FilterState['city']>(initial.city);
  const [condition, setCondition] = useState<FilterState['condition']>(initial.condition);

  useEffect(() => {
    if (open) {
      setQuery(initial.query);
      setCategory(initial.category);
      setCity(initial.city);
      setCondition(initial.condition);
    }
  }, [open, initial]);

  if (!open) return null;

  const handleApply = () => {
    onApply({ query, category, city, condition });
    onClose();
  };

  const handleCancel = () => {
    onClose();
  };

  const handleReset = () => {
    setQuery('');
    setCategory('all');
    setCity('all');
    setCondition('all');
  };

  const hasActiveFilter =
    query.trim() !== '' || category !== 'all' || city !== 'all' || condition !== 'all';

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm animate-fade-in sm:items-center sm:p-4">
      <div className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-3xl glass border border-slate-700/50 shadow-2xl animate-slide-up sm:rounded-3xl">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-700/40 bg-slate-900/80 px-5 py-4 backdrop-blur">
          <h2 className="text-lg font-extrabold text-white">Filtrele</h2>
          <div className="flex items-center gap-1">
            {hasActiveFilter && (
              <button
                onClick={handleReset}
                className="mr-1 inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs font-semibold text-slate-400 transition hover:text-orange-400"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Temizle
              </button>
            )}
            <button
              onClick={handleCancel}
              className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="space-y-6 px-5 py-5">
          {/* Model / Keyword search */}
          <div>
            <label className="mb-2 block text-sm font-bold text-slate-200">
              Model / Anahtar Kelime
            </label>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder='Örn: "Ferrari F40"'
                className="w-full rounded-xl border border-slate-700/50 bg-slate-900/60 py-3 pl-10 pr-3 text-sm text-slate-100 placeholder-slate-500 outline-none transition focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
              />
            </div>
          </div>

          {/* Category / Type tags */}
          <div>
            <label className="mb-2.5 block text-sm font-bold text-slate-200">
              Kategori / Tip
            </label>
            <div className="flex flex-wrap gap-2">
              <CategoryTag
                label="Tümü"
                active={category === 'all'}
                onClick={() => setCategory('all')}
              />
              {CATEGORIES.map((cat) => (
                <CategoryTag
                  key={cat}
                  label={CATEGORY_LABELS[cat]}
                  category={cat}
                  active={category === cat}
                  onClick={() => setCategory(cat)}
                />
              ))}
            </div>
          </div>

          {/* Condition / Box status */}
          <div>
            <label className="mb-2.5 block text-sm font-bold text-slate-200">
              Kutu & Kondisyon
            </label>
            <div className="flex flex-wrap gap-2">
              <ConditionTag
                label="Tümü"
                active={condition === 'all'}
                onClick={() => setCondition('all')}
              />
              {CONDITIONS.map((cond) => (
                <ConditionTag
                  key={cond}
                  label={CONDITION_STYLES[cond].label}
                  condition={cond}
                  active={condition === cond}
                  onClick={() => setCondition(cond)}
                />
              ))}
            </div>
          </div>

          {/* City selection */}
          <div>
            <label className="mb-2 block text-sm font-bold text-slate-200">
              Şehir / Konum
            </label>
            <select
              value={city}
              onChange={(e) => setCity(e.target.value as FilterState['city'])}
              className="w-full rounded-xl border border-slate-700/50 bg-slate-900/60 px-3.5 py-3 text-sm text-slate-100 outline-none transition focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
            >
              <option value="all">Tüm Şehirler</option>
              {TURKISH_CITIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Action buttons */}
        <div className="sticky bottom-0 flex gap-3 border-t border-slate-700/40 bg-slate-900/80 px-5 py-4 backdrop-blur">
          <button
            onClick={handleCancel}
            className="flex-1 rounded-xl border border-slate-700/50 py-3 text-sm font-bold text-slate-300 transition hover:bg-slate-700/40 active:scale-[0.98]"
          >
            İptal
          </button>
          <button
            onClick={handleApply}
            className="flex-[1.5] rounded-xl bg-gradient-flame py-3 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 active:scale-[0.98]"
          >
            Uygula / Devam
          </button>
        </div>
      </div>
    </div>
  );
}

function CategoryTag({
  label,
  active,
  onClick,
  category,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  category?: Category;
}) {
  const style = category ? CATEGORY_STYLES[category] : null;

  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-full border px-3.5 py-2 text-xs font-bold transition active:scale-95 ${
        active
          ? 'border-orange-500/70 bg-orange-500/15 text-orange-300 shadow-[0_0_12px_rgba(255,85,0,0.25)]'
          : 'border-slate-700/50 bg-slate-900/40 text-slate-400 hover:border-slate-600 hover:text-slate-200'
      }`}
    >
      {style && (
        <span className={`h-2 w-2 rounded-full ${style.dotClass}`} />
      )}
      {label}
      {active && <Check className="ml-0.5 h-3.5 w-3.5" />}
    </button>
  );
}

function ConditionTag({
  label,
  active,
  onClick,
  condition,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  condition?: Condition;
}) {
  const style = condition ? CONDITION_STYLES[condition] : null;

  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-full border px-3.5 py-2 text-xs font-bold transition active:scale-95 ${
        active
          ? style
            ? `${style.badgeClass} shadow-[0_0_10px_rgba(255,255,255,0.08)]`
            : 'border-orange-500/70 bg-orange-500/15 text-orange-300 shadow-[0_0_12px_rgba(255,85,0,0.25)]'
          : 'border-slate-700/50 bg-slate-900/40 text-slate-400 hover:border-slate-600 hover:text-slate-200'
      }`}
    >
      {style && (
        <span className={`h-2 w-2 rounded-full ${style.dotClass}`} />
      )}
      {label}
      {active && <Check className="ml-0.5 h-3.5 w-3.5" />}
    </button>
  );
}

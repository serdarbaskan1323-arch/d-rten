import { useState, useRef } from 'react';
import {
  X,
  ImagePlus,
  Trash2,
  Loader2,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Sparkles,
  Tag,
  RefreshCw,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { moderateImage, uploadListingImage } from '@/lib/moderation';
import { sanitizeText } from '@/lib/sanitize';
import { containsProfanity } from '@/lib/profanity';
import { CATEGORIES, CATEGORY_LABELS, TURKISH_CITIES, CONDITIONS, CONDITION_STYLES } from '@/constants';
import type { Category, Condition } from '@/types';

interface Props {
  open: boolean;
  onClose: () => void;
  onCreated: () => void;
}

interface UploadedImage {
  url: string;
  status: 'uploading' | 'validating' | 'approved' | 'rejected' | 'error';
  reason?: string;
}

type ListingType = 'sale' | 'trade' | 'both';

export function AddListingModal({ open, onClose, onCreated }: Props) {
  const { user } = useAuth();
  const { showToast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Category>('Regular');
  const [price, setPrice] = useState('');
  const [listingType, setListingType] = useState<ListingType>('sale');
  const [condition, setCondition] = useState<Condition | null>(null);
  const [city, setCity] = useState('');
  const [district, setDistrict] = useState('');
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  if (!open) return null;

  const showPrice = listingType === 'sale' || listingType === 'both';
  const isTrade = listingType === 'trade' || listingType === 'both';

  const handleFiles = async (files: FileList) => {
    if (!user) return;
    for (const file of Array.from(files)) {
      if (!file.type.startsWith('image/')) continue;
      const idx = images.length;
      setImages((prev) => [
        ...prev,
        { url: '', status: 'uploading' },
      ]);
      const url = await uploadListingImage(file, user.id);
      if (!url) {
        setImages((prev) =>
          prev.map((img, i) =>
            i === idx ? { ...img, status: 'error', reason: 'Yükleme başarısız' } : img
          )
        );
        continue;
      }
      setImages((prev) =>
        prev.map((img, i) => (i === idx ? { ...img, url, status: 'validating' } : img))
      );
      const mod = await moderateImage(url, file.name, file.size);
      setImages((prev) =>
        prev.map((img, i) =>
          i === idx
            ? mod.valid
              ? { ...img, status: 'approved' }
              : { ...img, status: 'rejected', reason: mod.reason || mod.error }
            : img
        )
      );
    }
  };

  const removeImage = (idx: number) => {
    setImages((prev) => prev.filter((_, i) => i !== idx));
  };

  const approvedImages = images.filter((i) => i.status === 'approved');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!user) {
      setFormError('İlan vermek için giriş yapmalısınız.');
      return;
    }
    if (!title.trim()) {
      setFormError('Lütfen bir başlık girin.');
      return;
    }
    if (!city) {
      setFormError('Lütfen şehir seçin.');
      return;
    }
    if (!district.trim()) {
      setFormError('Lütfen ilçe girin. İlçe bilgisi zorunludur.');
      return;
    }
    if (approvedImages.length === 0) {
      setFormError('En az bir onaylanmış görsel eklemelisiniz.');
      return;
    }
    if (containsProfanity(title)) {
      showToast('Başlıkta uygunsuz içerik (küfür/hakaret) tespit edildi.', 'error');
      return;
    }
    if (containsProfanity(description)) {
      showToast('Açıklamada uygunsuz içerik (küfür/hakaret) tespit edildi.', 'error');
      return;
    }
    if (containsProfanity(district)) {
      showToast('İlçe alanında uygunsuz içerik tespit edildi.', 'error');
      return;
    }
    if (!condition) {
      setFormError('Lütfen kutu & kondisyon durumu seçin.');
      return;
    }
    if (showPrice && !price) {
      setFormError('Satılık ilanlar için fiyat girin.');
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from('listings').insert({
      user_id: user.id,
      title: sanitizeText(title),
      description: sanitizeText(description) || null,
      category,
      price: showPrice && price ? parseFloat(price) : null,
      is_trade: isTrade,
      city: city || null,
      district: sanitizeText(district) || null,
      images: approvedImages.map((i) => i.url),
      condition,
      featured: false,
      status: 'active',
    });
    setSubmitting(false);
    if (error) {
      setFormError('İlan oluşturulurken bir hata oluştu.');
      return;
    }
    resetForm();
    onCreated();
    onClose();
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setCategory('Regular');
    setPrice('');
    setListingType('sale');
    setCondition(null);
    setCity('');
    setDistrict('');
    setImages([]);
    setFormError(null);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm animate-fade-in sm:items-center sm:p-4">
      <div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-2xl glass border border-slate-700/50 shadow-2xl animate-slide-up sm:rounded-2xl">
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-700/40 bg-slate-900/80 px-5 py-4 backdrop-blur">
          <h2 className="flex items-center gap-2 text-lg font-bold text-white">
            <ImagePlus className="h-5 w-5 text-orange-500" />
            Yeni İlan Ver
          </h2>
          <button onClick={handleClose} className="rounded-lg p-2 text-slate-400 transition hover:bg-slate-700/40 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 px-5 py-5">
          {/* Validation notice */}
          <div className="flex items-start gap-2 rounded-xl border border-orange-500/20 bg-orange-500/5 px-3 py-2.5 text-xs text-slate-300">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-orange-500" />
            <span>
              Yüklediğiniz görseller <span className="font-semibold text-orange-300">otomatik doğrulama</span> sisteminden geçer.
              Sadece Hot Wheels, diecast ve model araç görselleri kabul edilir. Uygunsuz içerik engellenir.
            </span>
          </div>

          {/* Images */}
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-300">Görseller</label>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => e.target.files && handleFiles(e.target.files)}
            />
            <div className="flex flex-wrap gap-3">
              {images.map((img, i) => (
                <div key={i} className="relative h-24 w-24 overflow-hidden rounded-xl border border-slate-700/50 bg-slate-800">
                  {img.url ? (
                    <img src={img.url} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center">
                      <Loader2 className="h-5 w-5 animate-spin text-orange-500" />
                    </div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center bg-black/60">
                    {img.status === 'uploading' && <Loader2 className="h-5 w-5 animate-spin text-white" />}
                    {img.status === 'validating' && <Loader2 className="h-5 w-5 animate-spin text-amber-400" />}
                    {img.status === 'approved' && <CheckCircle2 className="h-6 w-6 text-green-400" />}
                    {img.status === 'rejected' && <AlertCircle className="h-6 w-6 text-red-400" />}
                    {img.status === 'error' && <AlertCircle className="h-6 w-6 text-red-400" />}
                  </div>
                  <button
                    type="button"
                    onClick={() => removeImage(i)}
                    className="absolute right-1 top-1 rounded-full bg-black/70 p-1 text-white transition hover:bg-red-500"
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                  {img.status === 'rejected' && (
                    <div className="absolute bottom-0 left-0 right-0 bg-red-500/90 px-1 py-0.5 text-[8px] font-medium text-white">
                      Reddedildi
                    </div>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="flex h-24 w-24 flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-slate-600 text-slate-400 transition hover:border-orange-500/50 hover:text-orange-400"
              >
                <ImagePlus className="h-6 w-6" />
                <span className="text-[10px] font-medium">Görsel Ekle</span>
              </button>
            </div>
            {images.some((i) => i.status === 'rejected') && (
              <p className="mt-2 text-xs text-red-400">
                {images.some((i) => i.reason?.includes('uygunsuz'))
                  ? 'Yüklediğiniz görsel uygunsuz içerik tespit edildiği için reddedildi.'
                  : 'Hata: Yüklediğiniz görsel Hot Wheels veya model araçlar ile eşleşmiyor.'}
              </p>
            )}
            {images.some((i) => i.status === 'approved') && (
              <p className="mt-2 flex items-center gap-1 text-xs text-green-400">
                <CheckCircle2 className="h-3 w-3" />
                {approvedImages.length} görsel doğrulandı
              </p>
            )}
          </div>

          {/* Title */}
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-300">Başlık *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={100}
              placeholder="Örn: Hot Wheels Ferrari F40 - Premium"
              className="w-full rounded-xl border border-slate-700/50 bg-slate-900/60 px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
            />
          </div>

          {/* Category */}
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-300">Kategori / Tip *</label>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`rounded-lg border px-3 py-2 text-xs font-semibold transition ${
                    category === cat
                      ? 'border-orange-500/60 bg-orange-500/15 text-orange-300'
                      : 'border-slate-700/50 bg-slate-900/40 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {CATEGORY_LABELS[cat]}
                </button>
              ))}
            </div>
          </div>

          {/* Listing type — LED glow cards */}
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-300">İlan Türü *</label>
            <div className="grid grid-cols-3 gap-3">
              {/* Satılık — green LED */}
              <ListingTypeCard
                active={showPrice && !isTrade}
                onClick={() => setListingType('sale')}
                icon={<Tag className="h-5 w-5" />}
                label="Satılık"
                glowClass="sale"
              />
              {/* Takaslı — blue LED */}
              <ListingTypeCard
                active={isTrade && !showPrice}
                onClick={() => setListingType('trade')}
                icon={<RefreshCw className="h-5 w-5" />}
                label="Takaslı"
                glowClass="trade"
              />
              {/* İkisi — both glows */}
              <ListingTypeCard
                active={showPrice && isTrade}
                onClick={() => setListingType('both')}
                icon={
                  <span className="flex items-center">
                    <Tag className="h-4 w-4 text-green-400" />
                    <RefreshCw className="ml-0.5 h-4 w-4 text-blue-400" />
                  </span>
                }
                label="Satılık + Takas"
                glowClass="both"
              />
            </div>
          </div>

          {/* Price — shown when sale or both */}
          {showPrice && (
            <div className="animate-slide-up">
              <label className="mb-2 block text-sm font-semibold text-slate-300">Fiyat (TL) *</label>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="Örn: 1500"
                min="0"
                className="w-full rounded-xl border border-slate-700/50 bg-slate-900/60 px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
              />
            </div>
          )}

          {/* Condition / Box status */}
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-300">
              Kutu & Kondisyon Durumu <span className="text-orange-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {CONDITIONS.map((cond) => {
                const style = CONDITION_STYLES[cond];
                const isActive = condition === cond;
                return (
                  <button
                    key={cond}
                    type="button"
                    onClick={() => setCondition(cond)}
                    className={`flex items-center gap-2 rounded-lg border px-3 py-2.5 text-xs font-semibold transition ${
                      isActive
                        ? `${style.badgeClass}`
                        : 'border-slate-700/50 bg-slate-900/40 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span className={`h-2 w-2 shrink-0 rounded-full ${isActive ? style.dotClass : 'bg-slate-600'}`} />
                    {style.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* City / District — district mandatory */}
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-semibold text-slate-300">Şehir *</label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full rounded-xl border border-slate-700/50 bg-slate-900/60 px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-orange-500/60"
              >
                <option value="">Şehir seçin</option>
                {TURKISH_CITIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-2 block text-sm font-semibold text-slate-300">
                İlçe / Semt <span className="text-orange-500">*</span>
              </label>
              <input
                type="text"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                maxLength={50}
                placeholder="Örn: Kadıköy"
                className="w-full rounded-xl border border-slate-700/50 bg-slate-900/60 px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="mb-2 block text-sm font-semibold text-slate-300">Açıklama</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              maxLength={1000}
              placeholder="Modelin durumu, paket durumu, renk, seri vs..."
              className="w-full resize-none rounded-xl border border-slate-700/50 bg-slate-900/60 px-3 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
            />
          </div>

          {formError && (
            <p className="rounded-lg bg-red-500/10 border border-red-500/30 px-3 py-2 text-sm text-red-400">
              {formError}
            </p>
          )}

          <div className="flex gap-3 border-t border-slate-700/40 pt-4">
            <button
              type="button"
              onClick={handleClose}
              className="flex-1 rounded-xl border border-slate-700/50 py-2.5 text-sm font-bold text-slate-300 transition hover:bg-slate-700/40"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 rounded-xl bg-gradient-flame py-2.5 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 disabled:opacity-50 active:scale-[0.98]"
            >
              {submitting ? (
                <span className="inline-flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Yayınlanıyor...
                </span>
              ) : (
                <span className="inline-flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  İlanı Yayınla
                </span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ListingTypeCard({
  active,
  onClick,
  icon,
  label,
  glowClass,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  glowClass: 'sale' | 'trade' | 'both';
}) {
  const glowStyles: Record<string, { active: string; iconColor: string }> = {
    sale: {
      active: 'border-[#22c55e] shadow-[0_0_12px_rgba(34,197,94,0.8)]',
      iconColor: 'text-green-400',
    },
    trade: {
      active: 'border-[#3b82f6] shadow-[0_0_12px_rgba(59,130,246,0.8)]',
      iconColor: 'text-blue-400',
    },
    both: {
      active: 'border-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.7)]',
      iconColor: 'text-amber-400',
    },
  };

  const style = glowStyles[glowClass];

  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex flex-col items-center gap-1.5 rounded-xl border-2 px-3 py-3 transition duration-200 ${
        active
          ? `${style.active} bg-slate-800/60`
          : 'border-slate-700/50 bg-slate-900/40 text-slate-400 hover:border-slate-600'
      }`}
    >
      <span className={active ? style.iconColor : 'text-slate-500'}>{icon}</span>
      <span className={`text-xs font-bold ${active ? 'text-slate-100' : 'text-slate-400'}`}>
        {label}
      </span>
    </button>
  );
}

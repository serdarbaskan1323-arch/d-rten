import { useState } from 'react';
import { MapPin, Eye, RefreshCw, Flag } from 'lucide-react';
import type { ListingWithProfile } from '@/types';
import { CategoryBadge } from '@/components/CategoryBadge';
import { ConditionBadge } from '@/components/ConditionBadge';
import { ReportModal } from '@/components/ReportModal';
import { useAuth } from '@/context/AuthContext';
import { formatPrice, formatRelativeDate, formatLocation, buildGoogleMapsUrl } from '@/constants';

interface Props {
  listing: ListingWithProfile;
  onClick: () => void;
  onRequireAuth?: () => void;
}

export function ListingCard({ listing, onClick, onRequireAuth }: Props) {
  const { user } = useAuth();
  const [reportOpen, setReportOpen] = useState(false);
  const primaryImage = listing.images[0];

  return (
    <button
      onClick={onClick}
      className="group flex flex-col overflow-hidden rounded-2xl glass-card text-left transition duration-300 hover:-translate-y-1 hover:border-orange-500/30 hover:shadow-xl hover:shadow-orange-900/20"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-[length:16px_16px] bg-slate-850 bg-slate-900 bg-[linear-gradient(45deg,#1e293b_25%,transparent_25%,transparent_75%,#1e293b_75%),linear-gradient(45deg,#1e293b_25%,transparent_25%,transparent_75%,#1e293b_75%)] bg-[position:0_0,8px_8px]">
        {primaryImage ? (
          <img
            src={primaryImage}
            alt={listing.title}
            loading="lazy"
            className="h-full w-full object-contain p-2 transition duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-slate-600">
            <span className="text-3xl">🏎️</span>
          </div>
        )}
        <div className="absolute left-2 top-2">
          <CategoryBadge category={listing.category} />
        </div>
        {listing.condition && (
          <div className="absolute bottom-2 left-2">
            <ConditionBadge condition={listing.condition} />
          </div>
        )}
        {listing.featured && (
          <div className="absolute right-2 top-2 rounded-full bg-gradient-flame px-2 py-0.5 text-[10px] font-bold text-white shadow-lg">
            VİTRİN
          </div>
        )}
        {user && user.id !== listing.user_id && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setReportOpen(true);
            }}
            className="absolute right-2 bottom-2 rounded-lg bg-slate-900/80 p-1.5 text-slate-400 opacity-0 transition group-hover:opacity-100 hover:text-red-400"
            title="Şikayet Et"
          >
            <Flag className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      <div className="flex flex-1 flex-col p-3">
        <h3 className="mb-1.5 line-clamp-2 text-sm font-bold leading-snug text-slate-100 transition group-hover:text-orange-400">
          {listing.title}
        </h3>

        <div className="mb-2 flex items-center gap-1 text-xs text-slate-400">
          <MapPin className="h-3 w-3 shrink-0" />
          {(() => {
            const mapsUrl = buildGoogleMapsUrl(listing.city, listing.district);
            if (mapsUrl) {
              return (
                <a
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="truncate transition hover:text-orange-400"
                  onClick={(e) => e.stopPropagation()}
                >
                  {formatLocation(listing.city, listing.district)}
                </a>
              );
            }
            return <span className="truncate">{formatLocation(listing.city, listing.district)}</span>;
          })()}
        </div>

        <div className="mt-auto flex items-center justify-between">
          <div className="flex items-baseline gap-1.5">
            {listing.is_trade ? (
              <span className="inline-flex items-center gap-1 rounded-md bg-blue-500/15 px-2 py-0.5 text-xs font-bold text-blue-400">
                <RefreshCw className="h-3 w-3" />
                Takas
              </span>
            ) : (
              <span className="text-sm font-extrabold text-orange-400">
                {formatPrice(listing.price)}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1 text-[10px] text-slate-500">
            <Eye className="h-3 w-3" />
            {listing.views}
          </div>
        </div>
        <p className="mt-1.5 text-[10px] text-slate-600">{formatRelativeDate(listing.created_at)}</p>
      </div>

      {reportOpen && (
        <ReportModal
          open={reportOpen}
          onClose={() => setReportOpen(false)}
          reportedUserId={listing.user_id}
          reportedUserName={listing.profiles?.display_name || 'Satıcı'}
          listingId={listing.id}
          listingTitle={listing.title}
        />
      )}
    </button>
  );
}

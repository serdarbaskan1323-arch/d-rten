import { useState, useRef, useEffect } from 'react';
import {
  X,
  Send,
  ImagePlus,
  ArrowLeft,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Trash2,
  MessageSquare,
  Search,
  Ban,
} from 'lucide-react';
import { useChat } from '@/context/ChatContext';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { supabase } from '@/lib/supabase';
import { moderateImage, uploadListingImage } from '@/lib/moderation';
import { sanitizeText } from '@/lib/sanitize';
import { containsProfanity } from '@/lib/profanity';
import { formatRelativeDate } from '@/constants';

export function ChatPanel() {
  const {
    isOpen,
    closeChat,
    conversations,
    activeConversation,
    activeMessages,
    selectConversation,
    sendMessage,
  } = useChat();
  const { user } = useAuth();
  const { showToast } = useToast();
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pendingImage, setPendingImage] = useState<{ url: string; name: string } | null>(null);
  const [imageStatus, setImageStatus] = useState<'idle' | 'uploading' | 'validating' | 'approved' | 'rejected'>('idle');
  const [searchQuery, setSearchQuery] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeMessages]);

  if (!isOpen) return null;

  const handleAttachImage = async (file: File) => {
    if (!user) return;
    setImageStatus('uploading');
    setPendingImage(null);
    setError(null);

    const url = await uploadListingImage(file, user.id);
    if (!url) {
      setError('Görsel yüklenemedi.');
      setImageStatus('idle');
      return;
    }

    setImageStatus('validating');
    const mod = await moderateImage(url, file.name, file.size);
    if (!mod.valid) {
      setError('Bu görsel sohbet kurallarına uygun değil.');
      setImageStatus('rejected');
      return;
    }

    setPendingImage({ url, name: file.name });
    setImageStatus('approved');
  };

  const handleSend = async () => {
    if (!text.trim() && !pendingImage) return;
    if (containsProfanity(text)) {
      setError('Mesajınız uygunsuz içerik (küfür/hakaret) tespit edildiği için engellendi.');
      return;
    }
    setSending(true);
    setError(null);
    try {
      await sendMessage(sanitizeText(text), pendingImage?.url || null);
      setText('');
      setPendingImage(null);
      setImageStatus('idle');
    } catch {
      setError('Mesaj gönderilemedi. Lütfen tekrar deneyin.');
    }
    setSending(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleBlockUser = async () => {
    if (!user || !activeConversation) return;
    const { error: blockError } = await supabase
      .from('blocked_users')
      .insert({ blocker_id: user.id, blocked_id: activeConversation.other_user_id });
    if (blockError) {
      setError('Kullanıcı engellenemedi.');
      return;
    }
    showToast('Kullanıcı engellendi.', 'success');
    closeChat();
  };

  const removePendingImage = () => {
    setPendingImage(null);
    setImageStatus('idle');
  };

  const filteredConversations = searchQuery.trim()
    ? conversations.filter((c) =>
        c.other_display_name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : conversations;

  const showConversationList = !activeConversation;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-sm animate-fade-in"
        onClick={closeChat}
      />

      {/* Panel */}
      <div className="fixed right-0 top-0 z-[81] flex h-full w-full max-w-[480px] flex-col glass border-l border-slate-700/50 shadow-2xl animate-slide-in-right">
        {showConversationList ? (
          /* Conversation List */
          <>
            <div className="flex items-center justify-between border-b border-slate-700/40 px-4 py-4">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-orange-500" />
                <h2 className="text-lg font-extrabold text-white">Mesajlar</h2>
              </div>
              <button
                onClick={closeChat}
                className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-700/40 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {conversations.length > 5 && (
              <div className="border-b border-slate-700/40 px-4 py-2.5">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Sohbet ara..."
                    className="w-full rounded-xl border border-slate-700/50 bg-slate-900/60 py-2 pl-10 pr-3 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/60"
                  />
                </div>
              </div>
            )}

            <div className="flex-1 overflow-y-auto">
              {filteredConversations.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center text-center">
                  <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-slate-800">
                    <MessageSquare className="h-7 w-7 text-slate-500" />
                  </div>
                  <p className="text-sm font-semibold text-slate-300">Henüz mesaj yok</p>
                  <p className="mt-1 max-w-[220px] text-xs text-slate-500">
                    Bir ilana mesaj gönderdiğinizde sohbetleriniz burada görünecek.
                  </p>
                </div>
              ) : (
                filteredConversations.map((conv) => (
                  <button
                    key={conv.other_user_id}
                    onClick={() => selectConversation(conv.other_user_id)}
                    className={`flex w-full items-center gap-3 border-b border-slate-800/40 px-4 py-3 text-left transition hover:bg-slate-800/40 ${
                      conv.unread_count > 0 ? 'bg-slate-800/30' : ''
                    }`}
                  >
                    <div className="relative shrink-0">
                      {conv.other_avatar_url ? (
                        <img
                          src={conv.other_avatar_url}
                          alt=""
                          className="h-12 w-12 rounded-full object-cover"
                        />
                      ) : (
                        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-flame text-base font-bold text-white">
                          {conv.other_display_name.charAt(0).toUpperCase() || '?'}
                        </span>
                      )}
                      {conv.unread_count > 0 && (
                        <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-orange-500 px-1 text-[10px] font-bold text-white">
                          {conv.unread_count}
                        </span>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <p className={`truncate text-sm ${conv.unread_count > 0 ? 'font-bold text-white' : 'font-semibold text-slate-200'}`}>
                          {conv.other_display_name || 'Anonim'}
                        </p>
                        <span className="shrink-0 text-[10px] text-slate-500">
                          {formatRelativeDate(conv.last_message.created_at)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {conv.listing_image && (
                          <img
                            src={conv.listing_image}
                            alt=""
                            className="h-6 w-6 shrink-0 rounded object-contain bg-slate-800"
                          />
                        )}
                        <p className={`truncate text-xs ${conv.unread_count > 0 ? 'text-slate-300' : 'text-slate-500'}`}>
                          {conv.last_message.body || (conv.last_message.image_url ? 'Görsel' : '')}
                        </p>
                      </div>
                      {conv.listing_title && (
                        <p className="mt-0.5 truncate text-[10px] text-orange-400/80">
                          {conv.listing_title}
                        </p>
                      )}
                    </div>
                  </button>
                ))
              )}
            </div>
          </>
        ) : (
          /* Active Conversation */
          <>
            {/* Header */}
            <div className="flex items-center gap-3 border-b border-slate-700/40 px-4 py-3">
              <button
                onClick={() => selectConversation('')}
                className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-700/40 hover:text-white"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>

              <div className="relative shrink-0">
                {activeConversation.other_avatar_url ? (
                  <img
                    src={activeConversation.other_avatar_url}
                    alt=""
                    className="h-10 w-10 rounded-full object-cover"
                  />
                ) : (
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-flame text-sm font-bold text-white">
                    {activeConversation.other_display_name.charAt(0).toUpperCase() || '?'}
                  </span>
                )}
              </div>

              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-white">
                  {activeConversation.other_display_name || 'Anonim'}
                </p>
                {activeConversation.listing_title && (
                  <p className="truncate text-xs text-slate-400">
                    {activeConversation.listing_title}
                  </p>
                )}
              </div>

              <button
                onClick={handleBlockUser}
                className="rounded-lg p-1.5 text-slate-400 transition hover:bg-red-500/10 hover:text-red-400"
                title="Kullanıcıyı Engelle"
              >
                <Ban className="h-5 w-5" />
              </button>

              <button
                onClick={closeChat}
                className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-700/40 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 space-y-2 overflow-y-auto px-4 py-4">
              {activeMessages.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center text-center">
                  <div className="mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-slate-800">
                    <Send className="h-7 w-7 text-slate-500" />
                  </div>
                  <p className="text-sm font-semibold text-slate-300">Sohbeti başlat</p>
                  <p className="mt-1 max-w-[220px] text-xs text-slate-500">
                    {activeConversation.other_display_name || 'Satıcı'} ile mesajlaşın.
                  </p>
                </div>
              ) : (
                activeMessages.map((msg) => {
                  const isMine = msg.sender_id === user?.id;
                  return (
                    <div
                      key={msg.id}
                      className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[75%] rounded-2xl px-3.5 py-2.5 ${
                          isMine
                            ? 'bg-gradient-flame text-white rounded-br-md'
                            : 'bg-slate-800 text-slate-100 rounded-bl-md'
                        }`}
                      >
                        {msg.image_url && (
                          <img
                            src={msg.image_url}
                            alt="Görsel"
                            className="mb-1.5 max-h-48 rounded-lg object-contain bg-slate-900"
                          />
                        )}
                        {msg.body && (
                          <p className="whitespace-pre-wrap break-words text-sm leading-relaxed">
                            {msg.body}
                          </p>
                        )}
                        <p className={`mt-1 text-[10px] ${isMine ? 'text-white/70' : 'text-slate-500'}`}>
                          {formatRelativeDate(msg.created_at)}
                        </p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Pending image preview */}
            {pendingImage && (
              <div className="flex items-center gap-2 border-t border-slate-700/40 px-4 py-2 animate-slide-up">
                <div className="relative">
                  <img src={pendingImage.url} alt="" className="h-12 w-12 rounded-lg object-contain bg-slate-900" />
                  <button
                    onClick={removePendingImage}
                    className="absolute -right-1 -top-1 rounded-full bg-red-500 p-0.5 text-white"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
                <span className="flex items-center gap-1 text-xs text-green-400">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  Görsel eklendi
                </span>
              </div>
            )}

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 border-t border-red-500/20 bg-red-500/10 px-4 py-2 text-xs text-red-400 animate-fade-in">
                <AlertCircle className="h-4 w-4 shrink-0" />
                {error}
              </div>
            )}

            {/* Input */}
            <div className="flex items-center gap-2 border-t border-slate-700/40 px-3 py-3">
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleAttachImage(file);
                  e.target.value = '';
                }}
              />
              <button
                onClick={() => fileRef.current?.click()}
                disabled={imageStatus === 'uploading' || imageStatus === 'validating'}
                className="shrink-0 rounded-xl border border-slate-700/50 p-2.5 text-slate-400 transition hover:border-orange-500/50 hover:text-orange-400 disabled:opacity-50"
                title="Görsel Ekle"
              >
                {imageStatus === 'uploading' || imageStatus === 'validating' ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <ImagePlus className="h-5 w-5" />
                )}
              </button>

              <input
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Mesaj yazın..."
                className="flex-1 rounded-xl border border-slate-700/50 bg-slate-900/60 px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-orange-500/60 focus:ring-2 focus:ring-orange-500/20"
              />

              <button
                onClick={handleSend}
                disabled={sending || (!text.trim() && !pendingImage)}
                className="shrink-0 rounded-xl bg-gradient-flame p-2.5 text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 disabled:opacity-50 active:scale-95"
              >
                {sending ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <Send className="h-5 w-5" />
                )}
              </button>
            </div>
          </>
        )}
      </div>
    </>
  );
}

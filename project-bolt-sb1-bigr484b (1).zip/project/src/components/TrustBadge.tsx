import { ShieldCheck, Sparkles, BadgeCheck } from 'lucide-react';

export function TrustBadge() {
  return (
    <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-xs text-slate-300">
      <ShieldCheck className="h-4 w-4 text-orange-500" />
      <span className="font-medium">Otomatik Korumalı & Doğrulanmış İlan Platformu</span>
      <Sparkles className="h-3.5 w-3.5 text-amber-400" />
    </div>
  );
}

export function TrustBadgeMini() {
  return (
    <span className="inline-flex items-center gap-1.5 text-[11px] text-slate-400">
      <BadgeCheck className="h-3.5 w-3.5 text-orange-500" />
      Doğrulanmış
    </span>
  );
}

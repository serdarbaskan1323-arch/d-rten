import type { Condition } from '@/types';
import { CONDITION_STYLES } from '@/constants';

interface Props {
  condition: Condition;
  size?: 'sm' | 'md';
}

export function ConditionBadge({ condition, size = 'sm' }: Props) {
  const style = CONDITION_STYLES[condition];
  if (!style) return null;
  const sizeClass =
    size === 'md'
      ? 'px-3 py-1 text-xs'
      : 'px-2 py-0.5 text-[10px]';
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border font-semibold ${style.badgeClass} ${sizeClass}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${style.dotClass}`} />
      {style.label}
    </span>
  );
}

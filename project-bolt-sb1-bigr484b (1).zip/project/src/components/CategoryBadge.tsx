import type { Category } from '@/types';
import { CATEGORY_STYLES } from '@/constants';

interface Props {
  category: Category;
  size?: 'sm' | 'md';
}

export function CategoryBadge({ category, size = 'sm' }: Props) {
  const style = CATEGORY_STYLES[category];
  const sizeClass =
    size === 'md'
      ? 'px-3 py-1 text-xs'
      : 'px-2 py-0.5 text-[10px]';
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border font-semibold tracking-wide ${style.badgeClass} ${style.glow} ${sizeClass}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${style.dotClass}`} />
      {style.label}
    </span>
  );
}

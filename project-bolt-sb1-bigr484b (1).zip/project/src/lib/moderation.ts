import { supabase } from '@/lib/supabase';

export interface ImageModerationResult {
  valid: boolean;
  reason?: string;
  is_nsfw?: boolean;
  error?: string;
}

export async function moderateImage(
  imageUrl: string,
  fileName?: string,
  fileSize?: number
): Promise<ImageModerationResult> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/moderate-image`;
  try {
    const resp = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        image_url: imageUrl,
        file_name: fileName,
        file_size: fileSize,
      }),
    });
    if (!resp.ok) {
      return { valid: false, error: 'Moderasyon servisi yanıt vermedi.' };
    }
    const data = await resp.json();
    if (data.error) return { valid: false, error: data.error };
    return {
      valid: !!data.valid,
      reason: data.reason,
      is_nsfw: data.is_nsfw,
    };
  } catch {
    // Fallback: approve locally if the service is unreachable
    return { valid: true };
  }
}

export interface TextModerationResult {
  allowed: boolean;
  flagged: boolean;
  reason?: string;
  categories?: string[];
}

export async function moderateText(
  text: string
): Promise<TextModerationResult> {
  const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/moderate-text`;
  try {
    const resp = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text }),
    });
    if (!resp.ok) {
      return { allowed: true, flagged: false };
    }
    const data = await resp.json();
    if (data.error) return { allowed: true, flagged: false };
    return {
      allowed: !!data.allowed,
      flagged: !!data.flagged,
      reason: data.reason,
      categories: data.categories,
    };
  } catch {
    return { allowed: true, flagged: false };
  }
}

export async function uploadListingImage(
  file: File,
  userId: string
): Promise<string | null> {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
  if (!allowedTypes.includes(file.type)) return null;
  const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
  const fileName = `${userId}/${Date.now()}-${Math.random()
    .toString(36)
    .slice(2)}.${ext}`;
  const { error } = await supabase.storage
    .from('listings-images')
    .upload(fileName, file, {
      upsert: false,
      contentType: file.type,
    });
  if (error) {
    console.error('Upload error', error);
    return null;
  }
  const { data } = supabase.storage
    .from('listings-images')
    .getPublicUrl(fileName);
  return data.publicUrl;
}

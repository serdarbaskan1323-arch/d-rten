import { moderateText } from '@/lib/moderation';

const PROFANITY_TR = [
  "amk", "aq", "a.q", "amına", "amina", "amcık", "amcik",
  "sik", "s1k", "siq", "sikim", "siker", "sikti", "siktir", "sikdir",
  "piç", "pic", "p1ç", "orospu", "pezevenk", "pezo",
  "yarrak", "yarram", "yarrağım", "yarrağ",
  "göt", "got", "götün", "götveren", "gotveren",
  "kahpe", "lanet", "sg", "siktirgit",
  "ibne", "gavat", "puşt", "pusht",
  "oç", "o.c", "bok", "boktan",
  "şerefsiz", "serefsiz", "dalyarak", "dalyarrak",
  "yavşak", "yavsak", "sürtük", "surtuk",
  "pust", "amq",
];

export function containsProfanity(text: string): boolean {
  if (!text) return false;
  const lower = text
    .toLowerCase()
    .replace(/[^a-zçğıöşü0-9\s]/gi, ' ')
    .replace(/\s+/g, ' ');
  const words = lower.split(' ');
  return words.some((w) =>
    PROFANITY_TR.some(
      (p) => w === p || w.includes(p) || w.replace(/1/g, 'i').replace(/0/g, 'o').includes(p)
    )
  );
}

export async function checkContent(
  text: string,
  showToast?: (msg: string, type?: 'success' | 'error' | 'info') => void
): Promise<boolean> {
  if (containsProfanity(text)) {
    showToast?.('Mesajınız uygunsuz içerik (küfür/hakaret) tespit edildiği için engellendi.', 'error');
    return false;
  }
  const result = await moderateText(text);
  if (result.flagged) {
    showToast?.('Mesajınız uygunsuz içerik tespit edildiği için engellendi.', 'error');
    return false;
  }
  return true;
}

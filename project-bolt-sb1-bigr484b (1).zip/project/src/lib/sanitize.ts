/**
 * Strip HTML tags and control characters from user-provided text.
 * Prevents stored-XSS by ensuring no raw markup reaches the database
 * or is rendered back to other users.
 */
export function sanitizeText(input: string | null | undefined): string {
  if (!input) return '';
  return input
    .replace(/<[^>]*>/g, '')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .trim();
}

import type { Category, Condition } from '@/types';
import { CONDITIONS } from '@/types';

export const CATEGORIES: Category[] = [
  'Regular',
  'Silver',
  'Premium',
  'Chase',
  'STH',
  'TH',
];

export const CATEGORY_LABELS: Record<Category | 'all', string> = {
  all: 'Tüm Kategoriler',
  Regular: 'Regular',
  Silver: 'Silver',
  Premium: 'Premium',
  Chase: 'Chase',
  STH: 'STH (Super Treasure Hunt)',
  TH: 'TH (Treasure Hunt)',
};

interface CategoryStyle {
  label: string;
  badgeClass: string;
  dotClass: string;
  glow: string;
}

export const CATEGORY_STYLES: Record<Category, CategoryStyle> = {
  Regular: {
    label: 'Regular',
    badgeClass: 'bg-slate-700/60 text-slate-200 border-slate-500/40',
    dotClass: 'bg-slate-400',
    glow: '',
  },
  Silver: {
    label: 'Silver',
    badgeClass:
      'bg-gradient-to-r from-slate-300 to-slate-500 text-slate-900 border-slate-300',
    dotClass: 'bg-slate-300',
    glow: 'shadow-[0_0_12px_rgba(203,213,225,0.45)]',
  },
  Premium: {
    label: 'Premium',
    badgeClass:
      'bg-gradient-to-r from-amber-300 to-yellow-600 text-amber-950 border-amber-300',
    dotClass: 'bg-amber-400',
    glow: 'shadow-[0_0_14px_rgba(251,191,36,0.55)]',
  },
  Chase: {
    label: 'Chase',
    badgeClass:
      'bg-gradient-to-r from-fuchsia-500 to-purple-700 text-white border-fuchsia-400',
    dotClass: 'bg-fuchsia-400',
    glow: 'shadow-[0_0_14px_rgba(217,70,239,0.55)]',
  },
  STH: {
    label: 'STH',
    badgeClass:
      'bg-gradient-to-r from-yellow-300 via-amber-400 to-orange-500 text-amber-950 border-yellow-300',
    dotClass: 'bg-yellow-400',
    glow: 'shadow-[0_0_16px_rgba(250,204,21,0.65)]',
  },
  TH: {
    label: 'TH',
    badgeClass:
      'bg-gradient-to-r from-yellow-200 to-amber-500 text-amber-950 border-yellow-200',
    dotClass: 'bg-yellow-300',
    glow: 'shadow-[0_0_14px_rgba(253,224,71,0.6)]',
  },
};

export const TURKISH_CITIES: string[] = [
  'Adana', 'Adıyaman', 'Afyonkarahisar', 'Ağrı', 'Amasya', 'Ankara', 'Antalya',
  'Artvin', 'Aydın', 'Balıkesir', 'Bilecik', 'Bingöl', 'Bitlis', 'Bolu',
  'Burdur', 'Bursa', 'Çanakkale', 'Çankırı', 'Çorum', 'Denizli', 'Diyarbakır',
  'Edirne', 'Elazığ', 'Erzincan', 'Erzurum', 'Eskişehir', 'Gaziantep',
  'Giresun', 'Gümüşhane', 'Hakkari', 'Hatay', 'Isparta', 'Mersin', 'İstanbul',
  'İzmir', 'Kars', 'Kastamonu', 'Kayseri', 'Kırklareli', 'Kırşehir',
  'Kocaeli', 'Konya', 'Kütahya', 'Malatya', 'Manisa', 'Kahramanmaraş',
  'Mardin', 'Muğla', 'Muş', 'Nevşehir', 'Niğde', 'Ordu', 'Rize', 'Sakarya',
  'Samsun', 'Siirt', 'Sinop', 'Sivas', 'Tekirdağ', 'Tokat', 'Trabzon',
  'Tunceli', 'Şanlıurfa', 'Uşak', 'Van', 'Yozgat', 'Zonguldak', 'Aksaray',
  'Bayburt', 'Karaman', 'Kırıkkale', 'Batman', 'Şırnak', 'Bartın', 'Ardahan',
  'Iğdır', 'Yalova', 'Karabük', 'Kilis', 'Osmaniye', 'Düzce',
];

export function formatPrice(price: number | null): string {
  if (price === null || price === undefined) return 'Belirtilmemiş';
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY',
    maximumFractionDigits: 0,
  }).format(price);
}

export function formatRelativeDate(iso: string): string {
  const date = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHr / 24);
  if (diffMin < 1) return 'az önce';
  if (diffMin < 60) return `${diffMin} dakika önce`;
  if (diffHr < 24) return `${diffHr} saat önce`;
  if (diffDay < 7) return `${diffDay} gün önce`;
  return new Intl.DateTimeFormat('tr-TR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

interface ConditionStyle {
  label: string;
  badgeClass: string;
  dotClass: string;
}

export const CONDITION_STYLES: Record<Condition, ConditionStyle> = {
  'Sıfır / Sorunsuz': {
    label: 'Sıfır / Sorunsuz',
    badgeClass: 'bg-green-500/15 text-green-400 border-green-500/30',
    dotClass: 'bg-green-400',
  },
  'Koruma Kılıflı / Kablı': {
    label: 'Koruma Kılıflı / Kablı',
    badgeClass: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
    dotClass: 'bg-blue-400',
  },
  'Blisteri Hasarlı / Yırtık': {
    label: 'Blisteri Hasarlı / Yırtık',
    badgeClass: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
    dotClass: 'bg-amber-400',
  },
  'Kutusu Açık': {
    label: 'Kutusu Açık',
    badgeClass: 'bg-slate-500/20 text-slate-300 border-slate-500/30',
    dotClass: 'bg-slate-400',
  },
};

export { CONDITIONS };

export function formatLocation(city: string | null, district: string | null): string {
  if (city && district) return `${city} / ${district}`;
  if (city) return city;
  if (district) return district;
  return 'Konum belirtilmemiş';
}

export function buildGoogleMapsUrl(city: string | null | undefined, district: string | null | undefined): string | null {
  if (!city && !district) return null;
  const query = `${district ? district + ', ' : ''}${city ? city + ', ' : ''}Türkiye`;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

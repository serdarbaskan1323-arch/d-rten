import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { ToastProvider } from '@/context/ToastContext';
import { ChatProvider, useChat } from '@/context/ChatContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Drawer } from '@/components/Drawer';
import { AuthModal } from '@/components/AuthModal';
import { FilterModal } from '@/components/FilterModal';
import { AddListingModal } from '@/components/AddListingModal';
import { ChatPanel } from '@/components/ChatPanel';
import { HomePage } from '@/pages/HomePage';
import { SearchPage } from '@/pages/SearchPage';
import { ListingDetailPage } from '@/pages/ListingDetailPage';
import { ProfilePage } from '@/pages/ProfilePage';
import { AdminPage } from '@/pages/AdminPage';
import type { FilterState } from '@/types';

type Page = 'home' | 'search' | 'listing' | 'profile' | 'admin';

function AppContent() {
  const { user, loading } = useAuth();
  const { openChat } = useChat();
  const [page, setPage] = useState<Page>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<FilterState>({
    query: '',
    category: 'all',
    city: 'all',
    condition: 'all',
  });
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);
  const [addListingOpen, setAddListingOpen] = useState(false);
  const [currentListingId, setCurrentListingId] = useState<string | null>(null);

  const handleNavigate = (p: Page) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const handleOpenListing = (id: string) => {
    setCurrentListingId(id);
    setPage('listing');
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const handleSearchChange = (q: string) => {
    setSearchQuery(q);
    setFilter((prev) => ({ ...prev, query: q }));
  };

  const handleAddListing = () => {
    if (!user) {
      setAuthOpen(true);
      return;
    }
    setAddListingOpen(true);
  };

  const handleOpenProfile = () => {
    if (!user) {
      setAuthOpen(true);
      return;
    }
    setPage('profile');
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0f172a]">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-orange-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#0f172a]">
      <Header
        current={page}
        onNavigate={handleNavigate}
        searchQuery={searchQuery}
        onSearchChange={handleSearchChange}
        onOpenFilter={() => setFilterOpen(true)}
        onAddListing={handleAddListing}
        onOpenAuth={() => setAuthOpen(true)}
        onOpenProfile={handleOpenProfile}
        onToggleDrawer={() => setDrawerOpen(true)}
        onOpenChat={openChat}
      />

      <Drawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onNavigate={handleNavigate}
        onAddListing={handleAddListing}
        onOpenAuth={() => setAuthOpen(true)}
        onOpenProfile={handleOpenProfile}
      />

      <main className="flex-1">
        {page === 'home' && (
          <HomePage
            onOpenListing={handleOpenListing}
            onNavigateSearch={() => handleNavigate('search')}
            onAddListing={handleAddListing}
          />
        )}
        {page === 'search' && (
          <SearchPage
            filter={filter}
            onFilterChange={setFilter}
            onOpenFilter={() => setFilterOpen(true)}
            onOpenListing={handleOpenListing}
            onAddListing={handleAddListing}
          />
        )}
        {page === 'listing' && currentListingId && (
          <ListingDetailPage
            listingId={currentListingId}
            onBack={() => handleNavigate('search')}
            onRequireAuth={() => setAuthOpen(true)}
          />
        )}
        {page === 'profile' && (
          <ProfilePage onOpenListing={handleOpenListing} onAddListing={handleAddListing} />
        )}
        {page === 'admin' && user && (
          <AdminPage
            onBack={() => handleNavigate('home')}
            onOpenListing={handleOpenListing}
          />
        )}
      </main>

      <Footer onNavigateHome={() => handleNavigate('home')} />

      <ChatPanel />
      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />
      <FilterModal
        open={filterOpen}
        onClose={() => setFilterOpen(false)}
        onApply={setFilter}
        initial={filter}
      />
      <AddListingModal
        open={addListingOpen}
        onClose={() => setAddListingOpen(false)}
        onCreated={() => {
          if (page === 'home') handleNavigate('search');
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <ChatProvider>
          <AppContent />
        </ChatProvider>
      </ToastProvider>
    </AuthProvider>
  );
}
